({
    doInitChart : function(component, event, helper) {
        var recId = component.get("v.recordId");
        var action = component.get("c.getAccountRecord"); 
        action.setParams({'recordId': recId });
        action.setCallback(this, function(a) { 
            console.log(a.getReturnValue());
            component.set("v.graphData", a.getReturnValue()); 
            helper.accChart(component, event, helper);         
        });

        $A.enqueueAction(action);
        
    }
})