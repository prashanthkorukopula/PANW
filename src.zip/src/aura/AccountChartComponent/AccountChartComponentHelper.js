({
    accChart: function(component, event, helper)
    {      
            var temp="chart0";
            var ctx0;
            if(component.find("chart0")!=null)
                ctx0 = component.find("chart0").getElement();
            var ctx1;
            if(component.find("chart1")!=null)
                ctx1 = component.find("chart1").getElement();
            var ctx2;
            if(component.find("chart2")!=null)
                ctx2 = component.find("chart2").getElement();
            var graphData = component.get("v.graphData");
            var accAmt1 = 0;
            var accAmt2 = 0;
            var accAmt3 = 0;
            var accAmt4 = 0;
            var cusAmt1 = 0;
            var cusAmt2 = 0;
            var cusAmt3 = 0;
            var cusAmt4 = 0;
            var totAmt1 = 0;
            var totAmt2 = 0;
            var totAmt3 = 0;
            
            accAmt1 = graphData.Initial_BusinessValue__c;
            accAmt2 = graphData.Initial_NewBusinessLifeTimeWon__c - accAmt1;
            accAmt3 = graphData.Initial_TotalClosedNFR__c;
            accAmt4 = graphData.Initial_TotalOpen__c;
        
            cusAmt1 = graphData.Initial_BusinessClosedHierarchy__c;
            cusAmt2 = graphData.Initial_NewBusinessLifeTimeWonHierarchy__c - cusAmt1;
            cusAmt2 = cusAmt2.toFixed(2);
            cusAmt3 = graphData.Initial_TotalClosedNFRHierarchy__c;
            cusAmt4 = graphData.Initial_TotalOpenHierarchy__c;
        
            totAmt1 = graphData.Opportunity_Amount_Rollup__c;
            totAmt2 = graphData.Pipeline_Opportunity_Amount__c;
            totAmt3 = graphData.Total_Product_Revenue__c;
        
            var allElements = [accAmt1, accAmt2, accAmt3, accAmt4, cusAmt1, cusAmt2, cusAmt3, cusAmt4,totAmt1, totAmt2, totAmt3];
            var sortedElements = allElements.sort();
            var largest = sortedElements[10] + 1;
           
            if(ctx0!=null)
            {
                var temp="chart0";
                
                new Chart(ctx0, {
                    type: 'bar',
                    width: 300,
                    //Datasets with labels for each data and the label for the chart is given here
                    data: {
                        labels: ["Initial", "Expand", "NFR", "Open Opportunity $"],
                        datasets: [
                            {
                                label: "Account",
                                backgroundColor: ["#3e95cd","#F4D03F","#008000","#5D6D7E"],
                                data: [accAmt1,accAmt2,accAmt3,accAmt4]
                            }
                        ]
                    },
                    options: {
                         //To edit the tooltips
                         tooltips: {
                            callbacks: {
                                title: function(tooltipItems, data) {
                                    // Pick first xLabel for now
                                    var title = '';
                
                                    if (tooltipItems.length > 0) {
                                        if (tooltipItems[0].xLabel) {
                                            if(tooltipItems[0].xLabel =="Initial")
                                            title = "Account Initial Total";
                                            else if(tooltipItems[0].xLabel == "Expand")
                                                title = "Account New Business LifeTime Won";
                                            else if(tooltipItems[0].xLabel == "NFR")
                                                title = "Account Total NFR";
                                            else if(tooltipItems[0].xLabel == "Open Opportunity $")
                                                title ="Account Open Opportunity $";
                                            
                                        } else if (data.labels.length > 0 && tooltipItems[0].index < data.labels.length) {
                                            title = data.labels[tooltipItems[0].index];
                                        }
                                    }
                
                                    return title;
                                },
                                label: function(tooltipItem, data) {
                                    var datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
                                    var value = data.datasets[0].data[tooltipItem.index];
                                    value = value.toString();
                                    value = value.split('.');
                                    value[0] = value[0].split(/(?=(?:...)*$)/);
                                    value[0] = value[0].join(',');
                                    var newDataSetLabel;
                                    if(value[1] =='undefined' || value[1] ==null || value[1]=='')
                                        newDataSetLabel = datasetLabel + ' : ' +'$'+ value[0];
                                    else
                                        newDataSetLabel = datasetLabel + ' : ' +'$'+ value[0]+'.'+value[1];
                                    return [ newDataSetLabel];
                                }
                            }
                        },
                      legend: { 
                        display: false,
                        text: 'Account'
                        },
                      title: {
                        display: true,
                        text: 'Account'
                      },
                      scales: {
                        yAxes: [{
                            type: 'logarithmic',
                            ticks: {
                                beginAtZero:true,
                                userCallback: function(value, index, values) {
               
                                    var first = value;
                                 while(first >= 10)
                                  {
                                    first = first/10;
                                  }
                                  if(first==1)
                                     return value.toLocaleString();
                                }
                            }
                        }],
                        xAxes: [{
                            ticks: {
                            }
                        }]
                    }
                        
                    }
                });// End Chart 
            }// End If ctx != Null
        
       if(ctx1!=null)
            {
                var temp="chart1";
                
                component.chart = new Chart(ctx1, {
                    type: 'bar',
                    width:300,
                    data: {
                        labels: ["Initial", "Expand", "NFR", "Open Opportunity $"],
                        datasets: [
                            {
                                label: "Customer",
                                backgroundColor: ["#3e95cd","#F4D03F","#008000","#5D6D7E"],
                                data: [cusAmt1,cusAmt2,cusAmt3,cusAmt4]
                            }
                        ]
                    },
                    options: {
                        tooltips: {
                        callbacks: {
                            title: function(tooltipItems, data) {
                                // Pick first xLabel for now
                                var title = '';
                              if (tooltipItems.length > 0) {
                                    if (tooltipItems[0].xLabel) {
                                        if(tooltipItems[0].xLabel =="Initial")
                                        title = "Customer Initial Total";
                                        else if(tooltipItems[0].xLabel == "Expand")
                                            title = "Customer New Business LifeTime Won";
                                        else if(tooltipItems[0].xLabel == "NFR")
                                            title = "Customer Total NFR";
                                        else if(tooltipItems[0].xLabel == "Open Opportunity $")
                                            title ="Customer Open Opportunity $";
                                        
                                    } else if (data.labels.length > 0 && tooltipItems[0].index < data.labels.length) {
                                        title = data.labels[tooltipItems[0].index];
                                    }
                                }
            
                                return title;
                            },
                            label: function(tooltipItem, data) {
                                var datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
                                var value = data.datasets[0].data[tooltipItem.index];
                                value = value.toString();
                                value = value.split('.');
                                value[0] = value[0].split(/(?=(?:...)*$)/);
                                value[0] = value[0].join(',');
                                var newDataSetLabel;
                                if(value[1] =='undefined' || value[1] ==null || value[1]=='')
                                    newDataSetLabel = datasetLabel + ' : ' +'$'+ value[0];
                                else
                                    newDataSetLabel = datasetLabel + ' : ' +'$'+ value[0]+'.'+value[1];
                                return [ newDataSetLabel];
                            }
                        }
                    },
                      legend: { 
                        display: false,
                        text: 'Customer'
                        },
                      title: {
                        display: true,
                        text: 'Customer'
                      },
                      scales: {
                        yAxes: [{
                            type: 'logarithmic',
                            ticks: {
                                beginAtZero:true,
                                userCallback: function(value, index, values) {
                                    var first = value;
                                    while(first >= 10)
                                    {
                                        first = first/10;
                                    }
                                  if(first==1)
                                     return value.toLocaleString();
                                }
                            }
                        }],
                        xAxes: [{
                            ticks: {
                            }
                        }]
                    }
                       
                    }
                    
                });
            }// END Chart 2
         if(ctx2!=null)
            {
                var temp="chart2";
                
                component.chart = new Chart(ctx2, {
                    type: 'horizontalBar',
                    width: 100,
                    data: {
                        //labels: ["Lifetime Won Opportunity Amount", "Pipeline Opportunity Amount", "z Total Product Revenue"],
                        labels: ["Lifetime Won", "Pipeline"],
                        datasets: [
                            {
                                label: "Total",
                                backgroundColor: ["#3e95cd","#F4D03F"],
                                data: [totAmt1,totAmt2]
                            }
                        ]
                    },
                    options: {
        
                           tooltips: {
                            callbacks: {
                                title: function(tooltipItems, data) {
                                    // Pick first xLabel for now
                                    var title = '';
                
                                    if (tooltipItems.length > 0) {
                                        if (tooltipItems[0].yLabel) {
                                            if(tooltipItems[0].yLabel == "Lifetime Won")
                                                title = "Lifetime Won Opportunity Amount" ;
                                            else if(tooltipItems[0].yLabel == "Pipeline")
                                                title = "Pipeline Opportunity Amount" ;
                                           /* else if(tooltipItems[0].yLabel == "Product Revenue")
                                                title = "z Total Product Revenue";*/
                                        } else if (data.labels.length > 0 && tooltipItems[0].index < data.labels.length) {
                                            title = data.labels[tooltipItems[0].index];
                                        }
                                    }
                
                                    return title;
                                },
                                label: function(tooltipItem, data) {
                                    var datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
                                    var value = data.datasets[0].data[tooltipItem.index];
                                    value = value.toString();
                                    value = value.split('.');
                                    value[0] = value[0].split(/(?=(?:...)*$)/);
                                    value[0] = value[0].join(',');
                                    var newDataSetLabel;
                                    if(value[1] =='undefined' || value[1] ==null || value[1]=='')
                                        newDataSetLabel = datasetLabel + ' : ' +'$'+ value[0];
                                    else
                                        newDataSetLabel = datasetLabel + ' : ' +'$'+ value[0]+'.'+value[1];
                                    return [ newDataSetLabel];
                                }
                            }
                        },
                        
                      legend: { 
                        display: false,
                        text: 'Total'
                        },
                      title: {
                        display: true,
                        text: 'Total'
                      },
                      scales: {
                        yAxes: [{
                            ticks: {
                                
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                beginAtZero:true,
                                userCallback: function(value, index, values) {
                                    // Convert the number to a string and splite the string every 3 charaters from the end
                                    /*console.log('value ----->'+value);
                                    value = value.toFixed(2);
                                    if(value>0){
                                    value = value.toString();
                                    value = value.split(/(?=(?:...)*$)/);
                                    value = value.join(',');
                                    }
                                    return value;*/
                                    value = value.toFixed(2);
                                    value = value.toString();
                                    value = value.split('.');
                                    value[0] = value[0].split(/(?=(?:...)*$)/);
                                    value[0] = value[0].join(',');
                                    var value;
                                    if(value[1] =='undefined' || value[1] ==null || value[1]=='')
                                        value = value[0];
                                    else
                                        value =value[0]+'.'+value[1];
                                    return value;
                                    
                                }
                            }
                        }]
                    }
                    }
                    
                });
            } // End Chart 3
        
    }// End Accchart
})