({
	doInit : function(component, event, helper) {
        try{
        //RecordId of the Current RMA
        var recId = component.get("v.recordId");
        //CancelRMA method from RMACancellationController
        var action = component.get("c.cancelRMA");
        var urlEvent = $A.get("e.force:navigateToURL");
        var reDirectUrl ;

        reDirectUrl = "/apex/RMASubmittoSAP?id="+recId+"&Cancel=1";
        // set param to method  
        action.setParams({
            "recordId": component.get("v.recordId")
        });      
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            if(data != null){
                var SapDocNo = data.RMA_Id__r.SAP_Sales_Doc_No__c;
                if ((SapDocNo == '') || (SapDocNo == null) || (SapDocNo == 'undefined')) {
                    alert('RMA not yet submitted to SAP. Please make your changes before submitting to SAP.');
                	var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }else{
                    if(data.id){
                        alert('Your Request to cancel this RMA was unsuccessful as the replacement has already shipped or there was an error; please contact servicelogistics@paloaltonetworks.com to request this cancellation manually.');    
                    	var dismissActionPanel = $A.get("e.force:closeQuickAction");
                   		dismissActionPanel.fire();
                    }else{
                        // set the url to be directed to
                        urlEvent.setParams({
                            "url": reDirectUrl
                        });   
                        urlEvent.fire();    
                    }
                }
            }else{
                // set the url to be directed to
                urlEvent.setParams({
                    "url": reDirectUrl
                });   
                urlEvent.fire();    
            }
        });
        // enqueue the Action  
        $A.enqueueAction(action);
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
	}
})