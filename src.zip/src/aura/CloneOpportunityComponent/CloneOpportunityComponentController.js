({
	doInit : function(component, event, helper) { 
        helper.getCurrentOpportunityDetails(component);
	},
    
    doClose : function(component, event, helper) { 
		helper.doLexCloseAction(component, event, helper);
    },
    doClone : function(component, event, helper) { 
        helper.doCloneOppty(component, event, helper);      
	},
    doConfirm : function(component, event, helper) { 
         component.set('v.cloneConfirm',true);     
	},
    doConfirmClose : function(component, event, helper) { 
         component.set('v.cloneConfirm',false);     
	} 
})