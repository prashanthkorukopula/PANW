({
    getCurrentOpportunityDetails : function(component) {
		component.set("v.booleanShowSpinner",true);
		component.set("v.booleanShowErrorMessage",false);
        var action = component.get("c.getOpportuntytyDetails");	 
        var param = {
            opportunityId : component.get("v.recordId")
        };

        action.setParams(param);
        action.setCallback(this, function(a) {            
            if (a.getState() === "SUCCESS") 
            {                
                if(a.getReturnValue() != null)
                {      	
                    
                	component.set('v.OpptyName', a.getReturnValue().Name); 
                    component.set('v.dtClose', a.getReturnValue().CloseDate); 
                }
            }
			component.set("v.booleanShowSpinner",false);  
        });
        $A.enqueueAction(action);
    },
	doCloneOppty : function(component, event, helper) { 
	
		component.set("v.booleanShowSpinner",true);
		component.set("v.booleanShowErrorMessage",false);
		console.log('----Here----');
        if(component.get("v.OpptyName") == null || component.get("v.OpptyName") == '')
        {
			component.set("v.booleanShowSpinner",false);
			component.set("v.booleanShowErrorMessage",true);
			component.set("v.errorMessage","Please enter New Opportunity Name and proceed.");
            return;
        }
        var closeDate = component.get("v.dtClose");
        if(closeDate == undefined || closeDate == null || closeDate == '')
        {
			component.set("v.booleanShowSpinner",false);
			component.set("v.booleanShowErrorMessage",true);
			component.set("v.errorMessage","Please enter New Opportunity Close Date.");
            return;
        }
        if(closeDate !== undefined && closeDate !== null && closeDate !== '')  
        {            
            closeDate = closeDate.replace(/:/g,'\:');
        } 
        var param = {
            "opportunityId": component.get("v.recordId"),
            "opptyName" : component.get("v.OpptyName"),            
            "isProducts" : component.get("v.cloneProducts"),
            "closeDate" : closeDate
        };
        var action = component.get("c.getOpportunityDetailsAfterClone");	
        action.setParams(param);
        action.setCallback(this, function(a) {            
            if (a.getState() === "SUCCESS") {
				$A.get("e.force:closeQuickAction").fire();
                console.log(a.getReturnValue());
                if(a.getReturnValue() != null)
                {      				
                    helper.doLexCloseAction(component, event, helper);
                    var navEvt = $A.get("e.force:navigateToSObject");           
                 	if(navEvt)
                    {                        
                         navEvt.setParams({
                             "recordId": a.getReturnValue(),
                             "slideDevName": "detail"
                         });
                         navEvt.fire();
                        
                    }
                    
               }            
            } else if (a.getState() === "ERROR") { 
				console.log("Error");
				component.set("v.booleanShowSpinner",false);
				component.set("v.booleanShowErrorMessage",true);
				console.log(action.getError());
				var errors = action.getError();
				console.log(errors[0].fieldErrors);
				if (errors) {
					if (errors[0] && errors[0].message) {
						component.set("v.errorMessage",errors[0].message);

					}

				}
            }
			component.set("v.booleanShowSpinner",false);
        });
        $A.enqueueAction(action);
    },    
    doLexCloseAction : function(component, event, helper) { 
		$A.get("e.force:closeQuickAction").fire();
    },
    displayToast: function (type, title, message) {
        var toast = $A.get("e.force:showToast");
        if (toast) {
            toast.setParams({
                "type": type,
                "duration": 8000,
                "message": message
            });
            toast.fire();
        }
    }
})