({
    doInit : function (component, event, helper) {
          
        //Redirect to VF page - Lightining Migration 
        var rId = component.get("v.recordId");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/apex/BattleCardReport?accountid="+rId+"&retURL="+rId
        });
        urlEvent.fire();
    }
})