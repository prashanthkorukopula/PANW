({
	doInit : function(component, event, helper) {
        try{
        //Id of the current Contact Record
        var recId = component.get("v.recordId");
        //method getContactRecord from ContactComponentController
        var action = component.get("c.getContactRecord");
        //method getUserSalesLevel from ContactComponentController
        var salesLev = component.get("c.getUserSalesLevel");
        var sVal;
		var accId;
        var pqlId;
        var accName;
        // set param to method          
        action.setParams({
            "contactId": component.get("v.recordId")
        });
        // Register the callback function
		
		salesLev.setCallback(this, function(response) {
            sVal = response.getReturnValue();


             // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            if(data !=null && data !='undefined' && data!=''){
              
                    accId = data.AccountId;
                    if(data.Account!=null)
                    accName = data.Account.Name;
                    pqlId = data.PQL_Id__c;
                
                var urlEvent = $A.get("e.force:navigateToURL");
                
                if(sVal){
                    var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
                    dismissActionPanel.fire();
                    alert("You cannot create an Opportunity, if this is an error please contact Inside Sales Operations for assistant.");     
                }else{
                      // if(accId !=null && accId!='undefined' && accId!='' && pqlId !=null && pqlId!='undefined' && pqlId!='' ){
                      //   // set the url to be directed to
                      //   urlEvent.setParams({
                      //       "url": '/006/e?retURL=/'+recId+'&RecordType=01270000000HgepAAC&00N70000003gZio='+pqlId+'&opp4='+accName+' & opp4_lkid='+accId+'&accId='+accId
                      //   });   
                      //   urlEvent.fire();
                      // }else{
                      //  // set the url to be directed to
                      //   urlEvent.setParams({
                      //       "url": '/006/e?retURL=/'+recId+'&RecordType=01270000000HgepAAC'
                      //   });   
                      //   urlEvent.fire();    
                      // }

                       var urlstr='/apex/OpportunityDuplicateCheck?retURL=/'+recId+'&RecordType=01270000000HgepAAC';
                      
                      if(accId!=null)
                       urlstr='/apex/OpportunityDuplicateCheck?retURL=/'+recId+'&RecordType=01270000000HgepAAC'+'&opp4='+accName+'&opp4_lkid='+accId+'&accId='+accId;
                        if(pqlId!=null)
                       urlstr='/apex/OpportunityDuplicateCheck?retURL=/'+recId+'&RecordType=01270000000HgepAAC&00N70000003gZio='+pqlId+'&opp4='+accName+'&opp4_lkid='+accId+'&accId='+accId;
                        

                          urlEvent.setParams({
                              "url": urlstr,
                            "isredirect": "true"
                                
                          });  
                          console.log('hormese'); 
                          urlEvent.fire();  
                   
                }
            }
            
        });
         $A.enqueueAction(action);
        });

        // enqueue the Actions
        $A.enqueueAction(salesLev);
       
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
	}
})