({
    doInit : function(component, event, helper) {
        try{
        // Get a reference to the getWeather() function defined in the Apex controller
		var action = component.get("c.getAccountRecord");
        //recId is Case Id
        var recId = component.get("v.recordId");
       
        action.setParams({
            "accountId": component.get("v.recordId")
        });
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var recId = data.Id;
            var urlEvent = $A.get("e.force:navigateToURL");
            
            urlEvent.setParams({
                "url": "/apex/New_RMA?Caseid="+recId
            });   
            urlEvent.fire();
         
        });
        // Invoke the service
        $A.enqueueAction(action);
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
    }
    
})