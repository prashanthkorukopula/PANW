({
	  getRecords: function(component) {
          
        var action = component.get("c.getRecords");
        console.log('records---->',action);
        action.setCallback(this, function(a) {
            component.set("v.wrappers", a.getReturnValue());
            console.log('records---->',a.getReturnValue());
        });
        $A.enqueueAction(action);
    }
    
})