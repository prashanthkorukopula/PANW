({
	click : function(component, event, helper) {
		var clickEvt = $A.get("e.c:OutputClickEvent");
        clickEvt.setParams({ "fieldid":component.get("v.recordid")});
        clickEvt.fire();
	}
})