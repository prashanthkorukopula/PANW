({
	doInit: function(component, event, helper){
		var recId = component.get("v.recordId");
		var action = component.get("c.getRelatedList");
		
		action.setParams({
			"recordId": component.get("v.recordId"),
		});
		action.setCallback(this, function(response){
			var state = response.getState();
			console.log(response.getReturnValue());
			if (state === "SUCCESS") {
				if(response.getReturnValue() != null){
					component.set("v.inventories", response.getReturnValue());
					component.set("v.headerValue", "POC Inventory Reservations("+response.getReturnValue().length+")");
				}else{
					component.set("v.headerValue", "POC Inventory Reservations(0)");
					component.set("v.inventories", response.getReturnValue());
				}
				
			}
		});
		$A.enqueueAction(action);
	},
	editClick: function(component, event, helper){
		if(!event.target) return;
		if(event.target.parentNode === undefined) return;

		var idx = event.target.getAttribute("data-data") || event.target.parentNode.getAttribute("data-data");
		console.log('--index---'+idx);
		
		var urlEvent = $A.get("e.force:navigateToURL");
        var action = component.get("c.getRelatedList");
		
		action.setParams({
			"recordId": component.get("v.recordId"),
		});
		action.setCallback(this, function(response){
			var state = response.getState();
			console.log(response.getReturnValue());
			if (state === "SUCCESS") {
				if(response.getReturnValue() != null){
					
                    var inventoryId = response.getReturnValue()[idx];
                    console.log('---Inventory--'+inventoryId["Id"]);
                    var urlEvent = $A.get("e.force:navigateToURL");
					urlEvent.setParams({
                    "url": "/apex/POCScheduleEdit?id="+inventoryId["Id"]
                     });
                   urlEvent.fire();
                }
			}
		});
		$A.enqueueAction(action);
		// urlEvent.setParams({
		  // "url": 'https://www.google.com/maps/place/' + address
		// });
		//urlEvent.fire();
	},
	deleteClick:function(component, event, helper){
		if(!event.target) return;
		if(event.target.parentNode === undefined) return;

		var idx = event.target.getAttribute("data-data") || event.target.parentNode.getAttribute("data-data");
		console.log('--index---'+idx);
		
		
		var actionFetch = component.get("c.getRelatedList");
		var actionDelete = component.get("c.deleteRecord");
		var actionFinal = component.get("c.getRelatedList");
		var inventoryId;
		
		actionFetch.setParams({
			"recordId": component.get("v.recordId"),
		});
		
		
		
		actionFinal.setParams({
			"recordId":  component.get("v.recordId"),
		});
		actionFetch.setCallback(this, function(response){
			var state = response.getState();
			console.log(response.getReturnValue());
			if (state === "SUCCESS") {
				if(response.getReturnValue() != null){
                    inventoryId = response.getReturnValue()[idx]["Id"];
					console.log('---inventoryId'+inventoryId);
                    
					actionDelete.setParams({
						"recordId": inventoryId,
					});
				   $A.enqueueAction(actionDelete);
                }
			}
		});
		
		
		actionDelete.setCallback(this, function(response){
			var state = response.getState();
			console.log('---Delete--'+response.getReturnValue());
			if (state === "SUCCESS") {
				
				$A.enqueueAction(actionFinal);
				
				
				
			}
		});
		
		actionFinal.setCallback(this, function(response){
			var state = response.getState();
			console.log(response.getReturnValue());
			if (state === "SUCCESS") {
				if(response.getReturnValue() != null){
					component.set("v.inventories", response.getReturnValue());
					component.set("v.headerValue", "POC Inventory Reservations("+response.getReturnValue().length+")");
				}else{
					component.set("v.headerValue", "POC Inventory Reservations(0)");
					component.set("v.inventories", response.getReturnValue());
				}
			}
		});
		$A.enqueueAction(actionFetch);
		
		
	},
	hidePopup:function(component, event, helper){
		//Toggle CSS styles for hiding Modal
		helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
		helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
	},
	NewReserveInventory:function(component, event, helper){
		var recId = component.get("v.recordId");
		var action = component.get("c.newReserveInventory");
		
        action.setParams({
			"pocRequestId": component.get("v.recordId"),
		});
		action.setCallback(this, function(response){
			var state = response.getState();
            var result = response.getReturnValue();
			console.log('--result--'+result);
			console.log(response.getReturnValue());
			if (state === "SUCCESS") {
				if(result == true){
                    console.log('hi');
                    console.log('url-->',component.get("v.recordId"));
					var urlEvent = $A.get("e.force:navigateToURL");
					urlEvent.setParams({
                    "url": "/apex/POCSchedule?pocid="+component.get("v.recordId")
                     });
                   urlEvent.fire();
					console.log('over-->');
				}else{
					component.set("v.Message", "Only Assigned POC Engineer and Authorized Users can make Inventory reservations");
					helper.toggleClass(component,'backdrop','slds-backdrop--');
					helper.toggleClass(component,'modaldialog','slds-fade-in-');
				}
				
			}
		});
		$A.enqueueAction(action);
		
		
	},
    /* 
     * function name : navigateViewAll
     * return value  : none
     * description   : Executes when user clicks on the View all link on the related list
     */ 
    navigateViewAll: function(component, event,helper){
   		helper.navToRelatedList(component, event);
	},
	/* 
     * function name : navigateDetailView
     * return value  : none
     * description   : Executes when the user clicks to redirect to record detail view
     */ 
    navigateDetailView : function (component, event, helper) {
        helper.navigateToSObjectDetailView(component,event);
	},
    
});