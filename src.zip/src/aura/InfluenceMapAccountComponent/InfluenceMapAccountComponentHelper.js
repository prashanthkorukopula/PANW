({
    orgChart: {},
    clickEvent :{},
    dataSource : {},
    metaData: {},
    scriptLoaded : false,
    buyingRoleList : {},
    statusList : {},
    focusList : {},
    contactLevelList : {},
    focusValues : [],
    focusApis : [],
    focusChars : [],
    contactLevelValues : [],
    filterList: ["Same Account", "Related Account", "All Accounts"],

    chartZoom : 1,

    afterScriptHelper : function(component,event){
		// following block will change when we start recieving data from backend
        var action = component.get("c.getJsonOfInflunceMapRec");
        //001W000000apK4PIAU, 001W000000apVtOIAU, opp 006W000000CMOIuIAP
        action.setParams({recordId: component.get("v.recordId")});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                console.log('response : ', response.getReturnValue());
                this.setHelperVariables(response.getReturnValue());
                this.setComponentVariables(component,event);
                if (!component.get("v.isScriptLoaded")) {
                    component.set("v.isScriptLoaded", true);
                    if(this.dataSource && this.dataSource.id){
                        this.renderMapOnPage(component,event);
                    }
                    else{
                        this.showPlusButton(component);
                    }
                }
            }
            else{
                alert("No data received" + response.getState());
            }
        });
        $A.enqueueAction(action);

    },
    renderMapOnPage: function(component, event){
        var element;
        var self = this;
        setTimeout(function() {
            element = $(component.find('chart-Container').getElement());
            self.orgChart = element.orgchart({
                'data': self.dataSource,
                'draggable': true,
                'pan': true,
                'zoom': true,
                'exportButton': true,
                'exportFilename': "InfluenceMap",
                'createNode': function($node, data) {
                    //setting a unique id to every node.
                    $node[0].id = data.id;

                    //injecting the required HTML.
                    //padding:1px;border:2px solid '+ this.contactStatusColors[this.contactStatusValues.indexOf(data.status)]+'
                    $node[0].innerHTML =
                        '<div aura:id="node" class="nodeDiv slds-box">' +
                        		'<div aria-recordId="'+ data.id +'">' +
                        			'<p class="emptyDiv"></p>' +
                        			'<h4 aura:id="recordLink" class="recordLink">' + data.name + '</h4>' +
                        			'<h4 class="contactTitle">' + (data.title ? data.title : '&nbsp;') + '</h4>' +
                        			'<h5>' + (data.companyName ? data.companyName : '&nbsp;') + '</h5>' +
                        			'<div class="slds-grid indicatorsDiv">' +
                        				'<div class="slds-size--4-of-12">' +
                        					'<div aria-class="' + (data.buyingRole ? data.buyingRole : '') + '">'+
                    							'<div class="tooltip">'+
                        							(data.buyingRole ? data.buyingRole.charAt(0) : '') +
                        							'<span class="tooltiptext">' + (data.buyingRole ? data.buyingRole : '') + '</span>'+
                        						'</div>'+
                        					'</div>' +
                        				'</div>' +
                        				'<div class="slds-size--4-of-12 '+(data.status ? data.status : '')+'">' +
                        					'<div aria-class="' + (data.status ? data.status : '') + '">'+
                        						'<div class="tooltip">' +
                        							(data.status ? data.status.charAt(0) : '') +
                        							'<span class="tooltiptext">' + (data.status ? data.status : '') + '</span>'+
                        						'</div>'+
                        					'</div>' +
                        				'</div>' +
                        				'<div class="slds-size--4-of-12">' +
                        					'<div aria-class="' + (data.focus ? self.focusValues[self.focusApis.indexOf(data.focus)] : '') + '">'+
                        						'<div class="tooltip">' +
                        							(data.focus ? data.focus.charAt(0) : '') +
                        							'<span class="tooltiptext">' + (data.focus ? self.focusValues[self.focusApis.indexOf(data.focus)] : '') + '</span>'+
                        						'</div>'+
                        					'</div>' +
                        				'</div>' +
                        				'<div class="extraInfo">'+
                        					'<span>' + (data.phone ? data.phone : '') + '</span>'+
                        					'<span>' + (data.mail ? data.mail : '') + '</span>'+
                        				'</div>' +
                        			'</div>' +
                        			'<div class="slds-grid slds-p-top--xx-small">' +
                        				'<div class="slds-progress-bar tooltip progressBarDiv" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100" role="progressbar">' +
                        					'<span aria-class="' + (data.contactLevel ? data.contactLevel : '') + '" class="slds-progress-bar__value '+ (data.contactLevel ? data.contactLevel : '') + '"  title="' + (data.contactLevel ? data.contactLevel : '') + '">' +
                        						'<span class="tooltiptext">Level of Contact: ' + (data.contactLevel ? data.contactLevel : '') + '</span>'+
                        					'</span>'+
                        				'</div>'+
                        			'</div>' +
                        			'<div>' +
                        				'<div>' +
                                            '<i id="editNode" class="fa fa-pencil fa-fw" aria-hidden="true"></i>&nbsp;' +
                                            '<i id="deleteNode" class="fa fa-trash fa-fw" aria-hidden="true"></i>' +
                                            '<i id="addNode" class="fa fa-plus fa-fw"  aria-hidden="true"></i>&nbsp;' +
                        				'</div>' +
                        			'</div>';
                }
            })
        }, 100);
        $A.util.addClass(component.find("mapSpinner"), "slds-hide");
    },
    addNewNode : function(component, event, node){
        if(!this.dataSource || !this.dataSource.id){
            this.hidePlusButton();
            this.dataSource = {};
            this.dataSource.id = event.getParam("recordId");
            this.dataSource.parentId = event.getParam("parentId");
            // assign contactId, accountId as well
            this.dataSource.name = event.getParam("name");
            this.dataSource.title = event.getParam("title");
            this.dataSource.companyName = event.getParam("companyName");
            this.dataSource.buyingRole = event.getParam("buyingRole");
            this.dataSource.status = event.getParam("status");
            this.dataSource.focus = event.getParam("focus");
            this.dataSource.contactLevel = event.getParam("contactLevel");
            this.dataSource.phone = event.getParam("phone");
            this.dataSource.email = event.getParam("email");
            this.renderMapOnPage(component,event);
            return;
        }
        //Check if the focussed node already has a child or not.
        var hasChild = node.parent().attr('colspan') > 0 ? true : false;
        var oc = this.orgChart;
        //if not, Add a chid Node else add a sibling to the already present child Node(s).
        if(!hasChild){
            var data = {
                'children': [{
                    'id' : event.getParam("recordId"),
                    'parentId' : event.getParam("parentId"),
                    'name': event.getParam("name"),
                    'title': event.getParam("title"),
                    'companyName':event.getParam("companyName"),
                    'buyingRole': event.getParam("buyingRole"),
                    'status': event.getParam("status"),
                    'focus': event.getParam("focus"),
                    'contactLevel': event.getParam("contactLevel"),
                    'phone': event.getParam("phone"),
                    'email': event.getParam("email"),
                    'relationship': "110"
                }]
            }
            oc.addChildren(node, data);
        }
        else{
            //console.log('--closest sibling : ', node.closest('tr').siblings('.nodes').find('.node:first'));
            oc.addSiblings(node.closest('tr').siblings('.nodes').find('.node:first'), {
                'siblings': [{
                    'id' : event.getParam("recordId"),
                    'parentId' : event.getParam("parentId"),
                    'name': event.getParam("name"),
                    'title': event.getParam("title"),
                    'companyName' : event.getParam("companyName"),
                    'buyingRole': event.getParam("buyingRole"),
                    'status': event.getParam("status"),
                    'focus': event.getParam("focus"),
                    'contactLevel': event.getParam("contactLevel"),
                    'phone': event.getParam("phone"),
                    'email': event.getParam("email"),
                    'relationship': '110',
                    'Id': '12333'
                }]
            })
        }
    },
    updateNode : function(component, event, node){
        //recordId & parentId will remain as it is in JSON

        var contactName = event.getParam("name");
        var contactTitle = event.getParam("title");
        var contactCompanyName = event.getParam("companyName");
        var contactBuyingRole = event.getParam("buyingRole");
        var contactStatus = event.getParam("status");
        var contactFocus = event.getParam("focus");
        var contactPhone = event.getParam("phone");
        var contactEmail = event.getParam("email");
        var contactLevel = event.getParam("contactLevel");
        node[0].childNodes[1].innerText = contactName;
        node[0].childNodes[2].innerText = contactTitle ? contactTitle : ' ';
        node[0].childNodes[3].innerText = contactCompanyName ? contactCompanyName : ' ';
        //have to update buyingRole, Status, Focus values at three different places and change background color as well
        //changing aria-class value (used to populate modal picklists)
        node[0].childNodes[4].childNodes[0].childNodes[0].attributes[0].value = contactBuyingRole;
        node[0].childNodes[4].childNodes[1].childNodes[0].attributes[0].value = contactStatus;
        node[0].childNodes[4].childNodes[2].childNodes[0].attributes[0].value = contactFocus;

        //changing tooltip values
        node[0].childNodes[4].childNodes[0].childNodes[0].childNodes[0].childNodes[1].textContent = contactBuyingRole;
        node[0].childNodes[4].childNodes[1].childNodes[0].childNodes[0].childNodes[1].textContent = contactStatus;
        node[0].childNodes[4].childNodes[2].childNodes[0].childNodes[0].childNodes[1].textContent = contactFocus;
        //changing one alphabet
        node[0].childNodes[4].childNodes[0].childNodes[0].childNodes[0].childNodes[0].textContent = contactBuyingRole.charAt(0);
        node[0].childNodes[4].childNodes[1].childNodes[0].childNodes[0].childNodes[0].textContent = contactStatus.charAt(0);
        node[0].childNodes[4].childNodes[2].childNodes[0].childNodes[0].childNodes[0].textContent = contactFocus.charAt(0);

        //set border-color of Status value, any change in class name should be reflected here
        node[0].childNodes[4].childNodes[1].className = "slds-size--4-of-12 " + contactStatus;
		//extra-info
        node[0].childNodes[4].childNodes[3].childNodes[0].innerText = contactPhone;
        node[0].childNodes[4].childNodes[3].childNodes[1].innerText = contactEmail;

        //saving contacLevel value in aria-class attribute for re-reference, changing color & width of progress bar
        node[0].childNodes[5].childNodes[0].childNodes[0].attributes[0].textContent = contactLevel;
        node[0].childNodes[5].childNodes[0].childNodes[0].attributes[2].textContent = contactLevel;
        node[0].childNodes[5].childNodes[0].childNodes[0].childNodes[0].textContent = 'Level Of Contact : ' + contactLevel;

        //set width of contactLevel progressbar in the node, any change in class name should be reflected here
        node[0].childNodes[5].childNodes[0].childNodes[0].className = "slds-progress-bar__value " + contactLevel;
    },
    getRecord : function(component, recordId, data, record){
        //console.log("--data : ", data);
        if(!data)
            return;
        if(data.id == recordId){
            this.getRecordValues(data,record);
        	return;
        }
        else if(data.children){
            for(var i=0; i<data.children.length; i++)
                this.getRecord(component,recordId,data.children[i], record);
        }
    },
    getRecordValues : function(data,record){
        record.id = data.id;
        record.parentId = data.parentId;
        record.conId = data.conId;
        record.name = data.name;
        record.title = data.title;
        record.companyName = data.companyName;
        record.buyingRole = data.buyingRole;
        record.status = data.status;
        record.focus = data.focus;
        record.contactLevel = data.contactLevel;
        record.phone = data.phone;
        record.mail = data.mail;
        record.address = data.address;
    },
    updateComponentVariables : function(component,record, action){
        //console.log("--record : ", record);
        if(action === "Add"){
            component.set("v.nodeData.id", "");
            component.set("v.nodeData.parentId", record.id);
            component.set("v.nodeData.name","");
            component.set("v.nodeData.title","");
            component.set("v.nodeData.companyName","");
            component.set("v.nodeData.conId","");
            component.set("v.nodeData.buyingRole","");
            component.set("v.nodeData.status","");
            component.set("v.nodeData.focus","");
            component.set("v.nodeData.phone","");
            component.set("v.nodeData.email","");
            component.set("v.nodeData.contactLevel","");
            component.set("v.isViewClicked", false);
            component.set("v.modalHeader", "Add Contact Info");
            component.set("v.eventName", "Add");
            //temporary setup
            component.set("v.contact.Name", "");
        }
        else if(action === "Edit"){
            component.set("v.nodeData.id", record.id);
            //not setting parentId, it'll remain as it is
            component.set("v.nodeData.name", record.name);
            component.set("v.nodeData.title", record.title);
            component.set("v.nodeData.companyName", record.companyName);
            component.set("v.nodeData.conId",record.conId);
            component.set("v.nodeData.buyingRole", record.buyingRole);
            component.set("v.nodeData.status", record.status);
            component.set("v.nodeData.focus", record.focus);
            component.set("v.nodeData.phone", record.phone);
            component.set("v.nodeData.email", record.mail);
            component.set("v.nodeData.contactLevel", record.contactLevel);
            //temporary setup
            component.set("v.contact.Name", component.get("v.nodeData.name"));

            component.set("v.isViewClicked", false);
            component.set("v.modalHeader", "Edit Contact Info");
            component.set("v.eventName", "Edit");
    	}
    },
    updateJSON : function(component, event, action){
        var data = this.dataSource;

        if(action === "Add"){
            // here recordId is actually parent's Id, new nodes will have null in id field in JSON
            var recordId = event.getParam("parentId");
            this.addChildNode(data, event, recordId);
        }
        else if(action === "Edit"){
            var recordId = event.getParam("recordId");
            this.updateJSONNode(data, event, recordId);
        }
    },
    addChildNode : function(data, event, recordId){
        if(!data)
            return;
        if(data.id == recordId){
            var child = {};
            child.id = event.getParam("recordId");
            child.parentId = event.getParam("parentId");
            child.name = event.getParam("name");
            child.title = event.getParam("title");
            child.companyName = event.getParam("companyName");
            child.buyingRole = event.getParam("buyingRole");
            child.status = event.getParam("status");
            child.focus = event.getParam("focus");
            child.contactLevel = event.getParam("contactLevel");
            child.phone = event.getParam("phone");
            child.email = event.getParam("email");

            if(!data.children || data.children.length<=0)
                data.children = [];

            data.children.push(child);
            return;
        }
        else if(data.children){
            for(var i=0; i<data.children.length; i++)
                this.addChildNode(data.children[i],event,recordId);
        }
    },
    updateJSONNode : function(data, event, recordId){
        if(!data)
            return;
        if(data.id == recordId){
            data.id = recordId;
            data.name = event.getParam("name");
            data.title = event.getParam("title");
            data.companyName = event.getParam("companyName");
            data.buyingRole = event.getParam("buyingRole");
            data.status = event.getParam("status");
            data.focus = event.getParam("focus");
            data.contactLevel = event.getParam("contactLevel");
            data.phone = event.getParam("phone");
            data.mail = event.getParam("email");
            return;
        }
        else if(data.children){
            for(var i=0; i<data.children.length; i++)
                this.updateJSONNode(data.children[i],event,recordId);
        }
    },
    openContactModal : function(component){
        //open Modal
            component.set("v.openContactModal", true);
            //make modal header override salesforce navigation bar
            component.set("v.cssStyle", ".forceStyle .viewport .oneHeader.slds-global-header_container {z-index:0} .forceStyle.desktop .viewport{overflow:hidden}");
    },
    closeContactModal : function(component){
        component.set("v.openContactModal", false);
        //reset salesforce navigation bar css settings
        component.set("v.cssStyle", ".forceStyle .viewport .oneHeader.slds-global-header_container {z-index:5} .forceStyle.desktop .viewport{overflow:visible}");
    },
    deleteNode : function(component, event){
        var oc = this.orgChart;
        var node = this.clickEvent;

        oc.removeNodes(node);
        //$(event.target.parentElement).val("").data("node", "");
        this.orgChart = oc;
        var recordId = component.get("v.nodeData.id");
        component.set("v.nodeData.id","");
        if(this.dataSource.id == recordId){
            this.dataSource = {};
        	this.showPlusButton(component);
        }
        else{
            this.deleteJSONNode(this.dataSource, recordId);
        }
        this.closeDeleteModal(component);
    },
    goBackToRecord : function(component){
    	var recId = this.metaData.sObjectId;
        var backEvent = $A.get("e.force:navigateToSObject");
        backEvent.setParams({
            recordId: recId,
            isRedirect: true,
            slideDevName: "detail"
        });
        backEvent.fire();
    },
    setComponentVariables : function(component){
        if(this.metaData){
            var metaData = this.metaData;
            //console.log('metaData:~~ ', metaData);
            component.set("v.recordName",metaData.sObjectName);
            component.set("v.filterList",this.filterList);
            component.set("v.buyingRoleList",metaData.buyingRoleList);
            component.set("v.focusList",metaData.focusList);
            component.set("v.statusList",metaData.statusList);
            component.set("v.contactLevelList", metaData.contactLevelList);
        }
    	component.set("v.isInitialized", true);
    },
    setHelperVariables : function(response){
        //populating metaData & dataSource
        this.metaData = response.metaDataWrapper;
        this.dataSource = response.infDetailsWrapper;
        // save focus picklist values in local variables for quick access during add/edit operations
        for(var i=0; i<this.metaData.focusList.length; i++){
            this.focusValues.push(this.metaData.focusList[i].value);
            this.focusApis.push(this.metaData.focusList[i].api);
            this.focusChars.push(this.metaData.focusList[i].strChar);
        }
        //change values for Contect level list fore asy access
        for(var i=0; i<this.metaData.contactLevelList.length; i++){
            if(this.metaData.contactLevelList[i].api == "High")
            	this.metaData.contactLevelList[i].api = "100%";
            else if(this.metaData.contactLevelList[i].api == "Medium")
            	this.metaData.contactLevelList[i].api = "66.67%";
            else if(this.metaData.contactLevelList[i].api == "Low")
            	this.metaData.contactLevelList[i].api = "33.33%";
            //this.contactLevelValues.push(this.metaData.contactLevelList[i].value);
        }
        this.buyingRoleList = this.metaData.buyingRoleList;
        this.statusList = this.metaData.statusList;
        this.focusList = this.metaData.focusList;
        this.contactLevelList = this.metaData.contactLevelList;

    },
    showPlusButton : function(component){
        $("#plusDiv").css("display","block");
        $A.util.addClass(component.find("mapSpinner"),"slds-hide");
        if(this.metaData.sObjectType == "Opportunity")
            component.set("v.isOpportunityObject", "true");
        else
            component.set("v.isOpportunityObject", "false");
    },
    hidePlusButton : function(){
        $("#plusDiv").css("display","none");
    },
    redirectToSelectedContact : function(component, event){
        var recId = event.target.parentElement.parentElement.parentElement.getAttribute("id");
        console.log("recId : ", recId);
        //object is passed to functions as reference, variables are passed by value
        var contact = {};
        this.getContactId(this.dataSource,recId,contact);
        window.open("/"+contact.id, "_blank");
        /*var redirect = $A.get("e.force:navigateToURL");
        redirect.setParams({
            url: "/"+contact.id
        });
        redirect.fire();
        */
        /*
        var redirectEvent = $A.get("e.force:navigateToSObject");
        redirectEvent.setParams({
            recordId: contact.id,
            isRedirect: true,
            slideDevName: "detail"
        });
        redirectEvent.fire();
        */
    },
    getContactId : function(dataSource, recordId, contact){
        if(!dataSource)
            return;
        if(dataSource.id == recordId){
            contact.id = dataSource.conId;
            return;
        }
        else if(dataSource.children){
            for(var i=0; i<dataSource.children.length; i++)
                this.getContactId(dataSource.children[i], recordId, contact);
        }
    },
    openDeleteModal : function(component, event){
        component.set("v.showDeleteModal", "true");
        var recordId = event.target.parentElement.parentElement.parentElement.attributes[0].textContent;
        //saving recordId for easy reference in deleteNode function
        component.set("v.nodeData.id", recordId);
        //for reference in deleteNode function
        this.clickEvent = $(event.target.parentElement);
        if(recordId == this.dataSource.id){
            component.set("v.deleteModalMessage", "Do you want to delete entire map?");
        }
        else{
            component.set("v.deleteModalMessage", "Do you want to delete record?");
        }
    },
    closeDeleteModal : function(component){
        component.set("v.showDeleteModal", "false");
        component.set("v.deleteModalMessage", "");
    },
    deleteJSONNode : function(dataSource,recordId){

        if(!dataSource)
            return;
        if(dataSource.children){
            for(var i=0; i<dataSource.children.length; i++){
                if(dataSource.children[i].id == recordId){
                    dataSource.children.splice(i,1);
                    return;
                }
                else
                    this.deleteJSONNode(dataSource.children[i], recordId);
            }
        }
    }
 })