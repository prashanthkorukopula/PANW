({
    //afterRender is called when DOM Is loaded compltely with a delay of 6 secs.
    afterRender:function(component,helper){

    }
})