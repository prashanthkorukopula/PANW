({
    //afterRender is called when DOM Is loaded compltely with a delay of 6 secs.
    afterRender:function(component,helper){
        window.setTimeout(function(){ 
           //when users type something on the inputField this action will bind to the event.
            $('.inputSearch').bind( "keydown", function() {
                helper.openSuggestions(component, event, helper)
            });
          //when users select contact from the suggested Contact-List this action will bind to the event. 
            $('.suggestion').bind( "click", function() {
                helper.selectItem(component, event, helper)
            });
         },6000);  
    }
})