({
    /*******************************************************************************
     **** doInit function 
     **** This function will help to get the data from server on loading of the page.
     ********************************************************************************/
	doInit : function(component, event, helper) {
        // Calling the server side method in the contrller to get the data.
		var action = component.get("c.validateInfluenceMapComponent");
        // set the parameters for validateComponent method.
        action.setParams({
            recordId: component.get("v.recordId")
        });
        // Register the callback function
        action.setCallback(this,function(result){
            if(result.getState() =='SUCCESS'){
                var data = result.getReturnValue();
                console.log('data--->',data);
                //Navigating to the component based on data getting from server side.
                if(data == 'success'){
                    var evt = $A.get("e.force:navigateToComponent");
                    evt.setParams({
                        componentDef: "c:InfluenceMapComponent",
                        isredirect: true,
                        componentAttributes :{
                            recordId : component.get('v.recordId')
                        }
                    });
                	evt.fire();
            	}          
            }else{
                //Throwing the Error Message as State is ERROR
                console.log('error--->',result.getState())
                var errors = action.getError();
                if(errors){
                    if(errors[0] && errors[0].message){
                        component.set("v.Messageshow", true);
                        component.set('v.errorMessage', errors[0].message);
                    }
                }
            }
            
        });
        // enqueue the Action
        $A.enqueueAction(action);
	}
})