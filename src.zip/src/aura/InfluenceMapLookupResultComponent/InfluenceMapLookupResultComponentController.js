({
    /*
     * function name : selectedRecord
     * parameters    : none
     * return value  : none
     * description   : invokes an event to pass selected contact's details to the lookup component
     */
    selectedRecord: function(component, event, helper) {
        helper.selectedRecord(component);
    }
})