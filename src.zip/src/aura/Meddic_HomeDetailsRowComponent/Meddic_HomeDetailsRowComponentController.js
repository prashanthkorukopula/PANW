({
	editRecord : function(component, event, helper) {
        var cmpEvent = component.getEvent("editEvent");
			cmpEvent.setParams({
				"item":  component.get('v.item') 
			});
			cmpEvent.fire();
		
	}
})