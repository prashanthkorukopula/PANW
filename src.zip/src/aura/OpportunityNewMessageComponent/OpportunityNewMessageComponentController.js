({
	doInit : function(component, event, helper) {
        //Current Opp ID
        
		var recId = component.get("v.recordId");
        // method getAllMessages from OpportunityNewMessageController
        var action = component.get("c.getAllMessages");
        // set param to method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            console.log('Hormese'+response.getReturnValue());
            var AllMsgs = component.get("v.AllMsgs");
            component.set("v.AllMsgs",data);
            
        });
        // enqueue the Action
        $A.enqueueAction(action);
    },
    
    saveMessageJS : function(component, event, helper) {
       helper.saveMessageFunc(component, event, helper);
       $A.get('e.force:refreshView').fire();
    }
     
})