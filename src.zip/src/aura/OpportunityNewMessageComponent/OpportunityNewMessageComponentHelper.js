({
	saveMessageFunc : function(component, event, helper) {
        //Current Opp ID

        var recId = component.get("v.recordId");
        var newMessage = component.get("v.lastMsg");
        if(newMessage){
            // method getSaveMessage from OpportunityNewMessageController
            var action = component.get("c.saveMessage");
            // set param to method
            action.setParams({
                "newMsg": component.get("v.lastMsg"),
                "recordId": component.get("v.recordId")  
            });
            // Register the callback function
            action.setCallback(this, function(response) {
                var status = response.getState();
                var data = response.getReturnValue();
                if(status == 'SUCCESS'){
                    var toast = $A.get("e.force:showToast");
                    if (toast){
                        //fire the toast event in Salesforce1 and Lightning Experience
                        toast.setParams({
                            "title": "Success!",
                            "message": "Message saved succesfully"  
                        });
                        toast.fire();
                        
                    } 
                    console.log('Hormese'+data);
                    var AllMsgs = component.get("v.AllMsgs");
                    component.set("v.AllMsgs",data); 
                    
                    var afterMsg = component.get("v.lastMsg");
                    component.set("v.lastMsg",''); 
                    $A.get('e.force:refreshView').fire();
                }
            });  
            // enqueue the Action  
            $A.enqueueAction(action);
        }else{
        	var toast = $A.get("e.force:showToast");
            if (toast){
                //fire the toast event in Salesforce1 and Lightning Experience
                toast.setParams({
                    "title": "WARNING!!",
                    "message": "Message Not Added. Please Add New Message!!!!"  
                });
                toast.fire();
                
            } 	    
        }
    }
})