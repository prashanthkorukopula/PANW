({
    renderChart: function(component, event, helper) {

        // Current Opp ID
        var recId = component.get("v.recordId");
        //method getOpportunityAmts from OpportunityAmountChartController
        var action = component.get("c.getOpportunityAmts");
        // set param to method 1
        action.setParams({
            'RecordId': recId
        });

        // Register the callback function
        action.setCallback(this, function(a) {
            if (a.getState() == 'SUCCESS') {
                var data = a.getReturnValue();
                var a = 0;
                var b = 0;
                var c = 0;
                var d = 0;
                var e = 0;
                var f = 0;
                var g = 0;
                a = data.Sub_Amount_Aperture__c;
                b = data.Sub_Amount_Autofocus__c;
                c = data.Sub_Amount_Magnifier__c;
                d = data.sub_amount_traps__c;
                d = isNaN(d) ? 0 : d;
                //above line added because sub_amount_traps__c is currency field 
                // & if it's "blank" field, its being treated as undefined, affecting calculations
                e = data.MultiYear_Compensation__c;
                f = data.P_Amount__c;
                g = data.I_Amount__c;
                var totalCSS = a+b+c+d;
                var totalMulti = e+f+g;
                var allKeyValues = new Array(0);
                allKeyValues.push({key:'P Amount', value:f});
                allKeyValues.push({key:'I Amount', value:g});
                allKeyValues.push({key:'Multi Year Amount', value:e});
                allKeyValues.push({key:'Total', value:totalMulti});
                component.set("v.pimyAmount", allKeyValues);

                allKeyValues = new Array(0);
                allKeyValues.push({key:'Aperture', value:a});
                allKeyValues.push({key:'Autofocus', value:b});
                allKeyValues.push({key:'Magnifier', value:c});
                allKeyValues.push({key:'Traps', value:d});
                allKeyValues.push({key:'Total', value:totalCSS});
                component.set("v.cssAmount", allKeyValues);
            }
        });
        $A.enqueueAction(action);
    },

    renderCompensationCategoryChart: function(component, event, helper) {
        //method getOpportunityLineItemTotalPriceGroupBy from OpportunityAmountChartController
        var action = component.get("c.getOpportunityLineItemTotalPriceGroupBy");
        // Current Opp ID
        var oppId = component.get("v.recordId");
        // set param to method 2
        action.setParams({
            'RecordId': oppId
        });
        // Register the callback function
        /*action.setCallback(this, function(b) {
            var response = b.getReturnValue();
            var datasetComp = [];
            if(response != null){
                console.log('--Here--');
                var j = 0;
                var totalCompensation=0;
                var backgroundColor =['#1589ee','#F9600F','#DAF08A','#D7B0EE','#E0A68E','#04844b','#DAF7A6','#FF5733','#FFC300','#CABFC8','#B164A5','#53254C','#53254C','#306538','#306538'];
                for (var key in response) {
                    console.log('key = ' + key + ', value = ' + response[key]);
                    datasetComp[j] = {
                        data: [response[key]],
                        label: key,
                        backgroundColor:backgroundColor[j] ,
                    };
                    j = j+1;
                    totalCompensation += response[key];
                }
                console.log(datasetComp);
            }
            var temp2 = "CompensationCategory";
            var chartCompensationCategory;
            if (component.find("CompensationCategory") != null)
                chartCompensationCategory = component.find("CompensationCategory").getElement();
            //Options given for chart 3
            var barOptions_stacked = {
                //Used for changing the tooltips
                tooltips: {
                    enabled: true,
                    mode: "single",
                    callbacks: {
                        title: function(tooltipItems, data) {
                            // Pick first xLabel for now
                            var title = '';
                            return title;
                        },
                        label: function(tooltipItem, data) {
                            var datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
                            var valor = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                            var newDataSetLabel = datasetLabel + ' : ' +'$'+ valor.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
                            return [newDataSetLabel];
                        },
                        footer: function() {
                            return "Total : $" + totalCompensation;
                        }
                    },
                    yAlign: 'bottom'
                },
                hover: {
                    animationDuration: 0
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11,
                            userCallback: function(value, index, values) {
                                // Convert the number to a string and splite the string every 3 charaters from the end
                                value = value.toFixed(2);
                                value = value.toString();
                                value = value.split('.');
                                value[0] = value[0].split(/(?=(?: ...)*$)/);
                                value[0] = value[0].join(',');
                                var value;
                                if (value[1] == 'undefined' || value[1] == null || value[1] == '') value = value[0];
                                else value = value[0] + '.' + value[1];
                                return value;
                            }
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {},
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: true
                },
                pointLabelFontFamily: "Quadon Extra Bold",
                scaleFontFamily: "Quadon Extra Bold",
            };

            if (chartCompensationCategory != null) {
                var temp = "CompensationCategory";
                component.chart = new Chart(chartCompensationCategory, {
                    //To define the type of the chart
                    type: "doughnut",
                    responsive: true,
                    maintainAspectRatio: false,
                    data: {
                        //Label for the chart
                        labels: ["Compensation       "], //To define the datasets
                        datasets: datasetComp
                    },
                    options: barOptions_stacked,
                });
            }
        })*/
        action.setCallback(this, function(result) {
            if (result.getState() =='SUCCESS') {
                //var chartCompensationCategory = component.find("CompensationCategory").getElement();
                var response = result.getReturnValue();
                //var labels = new Array(0);
                //var data = new Array(0);
                var totalCompensation = 0;
                var allKeyValues = new Array(0);
                for (var key in response) {
                    //labels.push(key);
                    //data.push(response[key]);
                    totalCompensation += Number(response[key]);
                    allKeyValues.push({key:key,value:response[key]});
                }
                allKeyValues.push({key:'Total', value:totalCompensation});
                component.set("v.compensationCategory", allKeyValues);

                /*var backgroundColor =['#1589ee','#F9600F','#DAF08A','#D7B0EE','#E0A68E','#04844b','#DAF7A6','#FF5733','#FFC300','#CABFC8','#B164A5','#53254C','#53254C','#306538','#306538'];
                component.chart = new Chart(chartCompensationCategory, {
                    type: 'doughnut',
                    data: {
                        labels: labels,
                        datasets:[ {
                            //label: 'Compensation',
                            backgroundColor : backgroundColor,
                            data : data
                        }]
                    },
                    options: {
                        title:{
                            display:true,
                            text:'Compensation Category'
                        },
                        legend:{
                            display:true,
                            position:'bottom'
                        },
                        tooltips: {
                            enabled: true,
                            mode: "single",
                            callbacks: {
                                title: function(tooltipItems, data) {
                                    // Pick first xLabel for now
                                    var title = '';
                                    return;
                                },
                                label: function(tooltipItem, data) {
                                    var datasetLabel = data.labels[tooltipItem.index] || '';
                                    var valor = data.datasets[0].data[tooltipItem.index];
                                    var newDataSetLabel = datasetLabel + ' : ' +'$'+ valor.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
                                    return [newDataSetLabel];
                                }//,
                                //footer: function() {
                                //    return "Total : $" + totalCompensation;
                                //}
                            }, // xAlign: 'bottom',
                            yAlign: 'bottom'
                        }
                    }
                });*/
            }
        });
        $A.enqueueAction(action);

    }

})