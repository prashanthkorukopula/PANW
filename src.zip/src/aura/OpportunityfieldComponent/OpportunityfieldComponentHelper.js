({
    toggleClass: function(component,componentId,className) {
        var modal = component.find(componentId);
        $A.util.removeClass(modal,className+'hide');
        $A.util.addClass(modal,className+'open');
    },

	toggleClassInverse: function(component,componentId,className) {
        var modal = component.find(componentId);
        $A.util.addClass(modal,className+'hide');
        $A.util.removeClass(modal,className+'open');
    },

	//Helper to Save Opportunity after Updating EDI Fields
	saveOppRec: function(component, event, helper){
		var oppInfo = component.get("v.objOpp");
		
		var recId = component.get("v.recordId");
		var actionSave = component.get("c.saveOpportunity");
		var actionFetch = component.get("c.getRecordInfo");
        var ordervaalue = component.find("OrderIssue").get("v.value")
		actionSave.setParams({
			"objOpportunity": component.get("v.objOpp"),
			"OrderValues":ordervaalue,
		});
        actionFetch.setParams({
			"idRecord": recId,
		});
		actionSave.setCallback(this, function(response){
			var state = response.getState();
			if (state === "SUCCESS") {
				component.set("v.displayInput",false);
				component.set("v.displayOutput",true);
				helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
				helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
				 console.log(response.getReturnValue());
				 component.set("v.objOpp", response.getReturnValue());
			}
		});
		actionFetch.setCallback(this, function(response){
			var state = response.getState();
			console.log('---Response---'+response.getReturnValue());
			if (state === "SUCCESS") {
				component.set("v.objOpp", response.getReturnValue());
				helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
				helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
			}
		});
		$A.enqueueAction(actionSave);
		$A.enqueueAction(actionFetch);
	},
    
    // Helper Method to Allow edit Based on Profile
    editEDI: function(component, event, helper){
        var recId = component.get("v.recordId");
        var actionBoolean = component.get("c.getProfileVisibility");
        actionBoolean.setCallback(this,function(response){
			var state = response.getState();
			console.log('--Profile--'+response.getState());
            if(state === "SUCCESS"){
                component.set("v.displayEdit", response.getReturnValue());
            }
        });
        $A.enqueueAction(actionBoolean);
    },
    
    //Helper Method to set the Order Issue Picklist values onLoad
    setOrderIssuePicklist: function(component, event, helper){
    	var recId = component.get("v.recordId");
        var actionPicklist = component.get("c.GetFieldPikclistValues");
		actionPicklist.setParams({
			"ObjectApi_name": 'Opportunity',
			"picklistField":'Order_Issue__c'
		});        
        actionPicklist.setCallback(this, function(response){
			var state = response.getState();
			console.log('--SetOrder--'+response.getState());
			if (state === "SUCCESS") {
				component.set("v.OrderPicklistValues", response.getReturnValue());
			}
		});
        $A.enqueueAction(actionPicklist);
    },  
    
    //Helper Method toset the Order Issue Picklist values onLoad
    setOrderIssueValue: function(component, event, helper){
        var recId = component.get("v.recordId");
        var action = component.get("c.getRecordInfo");
        action.setParams({
			"idRecord": recId,
		});
        action.setCallback(this, function(response){
			var state = response.getState();
			console.log('--SetOrderValue--'+response.getState());
			if (state === "SUCCESS") {
				component.set("v.objOpp", response.getReturnValue());
                var objOrder=component.get("v.objOpp");
                if(objOrder.Order_Issue__c != undefined && objOrder.Order_Issue__c != null ){
					// component.find("OrderIssue").set("v.value", objOrder.Order_Issue__c);
				}
				 // component.find("OrderIssue").set("v.options",);
			}
		});
    	$A.enqueueAction(action);    
    }
 })