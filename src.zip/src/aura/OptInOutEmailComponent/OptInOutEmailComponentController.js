({
	doInit : function(component, event, helper) {
		
            
            var alertMsg = '';
            var actOptOut;
            console.log('entered');
            //Id of the current Lead Record
            var recId = component.get("v.recordId");
            var action = component.get("c.getAccountRec");   
            // set param to method   
            action.setParams({
                "recordId": component.get("v.recordId")
            });
                    
            // Register the callback function
            action.setCallback(this, function(response) {
                var status = response.getState();
                
                var dataVal = response.getReturnValue();
                if(dataVal != null){
                	// check if opted in or out currently and build a message - should we use labels???
                    if(dataVal){
                        alertMsg = 'The contacts for this account are currently opted-out for Welcome Email Program. Are you sure you want to OPT-IN ALL previously opted-in contacts for this account to the Welcome Email Program?';
                    }else{
                        alertMsg = 'The contacts for this account are currently opted-in for Welcome Email Program. Are you sure you want to OPT-OUT ALL contacts for this account from Welcome Email Program?';
                    }
                    
                    component.set("v.alertMessage",alertMsg);
                    var modal = component.find("modalMessage");
                    $A.util.removeClass(modal,'slds-hide');
                    $A.util.addClass(modal,'slds-show');
                    
            	}
                
            });
            $A.enqueueAction(action);
        	
                    
	},
    saveAccount : function(component, event, helper){
        $A.get("e.force:closeQuickAction").fire() ;
        var dataValnew = component.get("v.emailBooleanValue");
        var actOptOut = false;
        if(dataValnew){
            actOptOut = false;
        }else{
            actOptOut = true;
        }
        //Id of the current Lead Record
        var recId = component.get("v.recordId");
        var actionSave = component.get("c.saveAccountRec");
        // set param to method   
        actionSave.setParams({
            "recordId": component.get("v.recordId"),
            "optInOut":actOptOut
        });
        actionSave.setCallback(this, function(response) {
            $A.get('e.force:refreshView').fire();
        });
        $A.enqueueAction(actionSave);
    },
    closeModal : function(component, event, helper){
        $A.get("e.force:closeQuickAction").fire() ;
    }
})