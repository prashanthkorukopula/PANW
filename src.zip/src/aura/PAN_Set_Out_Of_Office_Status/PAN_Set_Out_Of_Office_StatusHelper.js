({
	helperFun : function(component,event,secId) {
	  var acc = component.find(secId);
        	for(var cmp in acc) {
        	$A.util.toggleClass(acc[cmp], 'slds-show');  
        	$A.util.toggleClass(acc[cmp], 'slds-hide');  
       }
	},
    helpereditsection : function(component,event) {
        var acc = component.find('initialItem');
        var displaycomp = component.find('editItem');
        var edtbtn = component.find('editbtn');
        var displaypanel = component.find('editpanel');
        var savebtn = component.find('savebtn');
        var getCheckVal = component.find('firstCheck').get("v.value");
        console.log('value of checkbox first call '+getCheckVal);
        console.log('function entered here--');
        $A.util.removeClass(acc, 'slds-show');
        $A.util.addClass(acc, 'slds-hide');
        if(getCheckVal){
            $A.util.removeClass(displaypanel, 'slds-hide');
        	$A.util.addClass(displaypanel, 'slds-show');
        }else{
            $A.util.removeClass(displaycomp, 'slds-hide');
        	$A.util.addClass(displaycomp, 'slds-show');
        }
        $A.util.removeClass(edtbtn, 'slds-show');
        $A.util.addClass(edtbtn, 'slds-hide');
        $A.util.removeClass(savebtn, 'slds-hide');
        $A.util.addClass(savebtn, 'slds-show');	
       
	},
    helpereditpanel : function(component,event) {
	  var getCheckVal = component.find('firstCheck').get("v.value");
        
        if(getCheckVal){
            var acc = component.find('editItem');
      		var displaycomp = component.find('editpanel');
            $A.util.removeClass(acc, 'slds-show');
        	$A.util.addClass(acc, 'slds-hide');
        	$A.util.removeClass(displaycomp, 'slds-hide');
        	$A.util.addClass(displaycomp, 'slds-show');	
            console.log('value of checkbox '+getCheckVal);
        }
    },
    helperSavedata: function(component) {
        //Save the expense and update the view
        var action = component.get("c.saveuser");
        action.setParams({ 
            "userObj": component.get('v.runningUser')
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var rec = response.getReturnValue();
                console.log('Status---',state);
            }
        });
        $A.enqueueAction(action);
    },
    
    
})