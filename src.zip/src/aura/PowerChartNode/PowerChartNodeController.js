({
    doInit : function(component, event, helper) {
        window.setTimeout(function(){
            var availableTags = [ "ActionScript", "AppleScript", "Asp", "BASIC", "C", "C++", "Clojure", "COBOL", "ColdFusion", "Erlang", "Fortran", "Groovy", "Haskell", "Java", "JavaScript", "Lisp", "Perl", "PHP", "Python", "Ruby", "Scala", "Scheme" ];
            var input = component.find('input').getElement();
            $(input).autocomplete({
                source: availableTags
            });
        },2000);
    },
    openSuggestions:  function(component,event,helper,dataSource) { 
        // var dataSource =   component.get('v.dataSource');   
        var dataSource =               
            [
                { 'name': 'Jack', 'email':'Jack@gmail.com', 'oppRole':'CEO', 'organization':'I.T', 'id':'1' },
                { 'name': 'Jill', 'email':'Jill@gmail.com', 'oppRole':'Tech Head', 'organization':'I.T', 'id':'2' },
                { 'name': 'June', 'email':'June@gmail.com', 'oppRole':'VP', 'organization':'I.T', 'id':'3' },
            ]
                helper.openSuggestions(component,event,helper,dataSource);
  },
  selectItem : function(component,event,helper,dataSource) {
    //  var dataSource = component.get('v.dataSource'); 
        var dataSource =               
            [
                { 'name': 'Jack', 'email':'Jack@gmail.com', 'oppRole':'CEO', 'organization':'I.T', 'id':'1' },
                { 'name': 'Jill', 'email':'Jill@gmail.com', 'oppRole':'Tech Head', 'organization':'I.T', 'id':'2' },
                { 'name': 'June', 'email':'June@gmail.com', 'oppRole':'VP', 'organization':'I.T', 'id':'3' },
            ]
        helper.selectItem(component,event,helper,dataSource);          
    },
    closeSuggestion:function(component,event,helper,dataSource){
        component.find('suggestion').getElement().innerHtml = "";
        component.find('suggestion').getElement().style.display = "none";
    }          
})