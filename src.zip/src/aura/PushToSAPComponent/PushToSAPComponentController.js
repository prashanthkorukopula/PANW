({
	doInit : function(component, event, helper) {
        try{
        var recId = component.get("v.recordId");
        var urlEvent = $A.get("e.force:navigateToURL");
            
        if (typeof(srcUp) == 'function'){ 
            urlEvent.setParams({
                "url": "/apex/UpdateOppSAP?isdtp=vw&id="+recId
            });   
            urlEvent.fire(); 
        }else{ 
            urlEvent.setParams({
                "url": "/apex/UpdateOppSAP?id="+recId
            });   
            urlEvent.fire();  
        }
        }catch(e){
           throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
	}
})