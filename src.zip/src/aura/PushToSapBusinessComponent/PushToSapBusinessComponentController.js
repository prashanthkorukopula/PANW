({
    /***********************************************************************************
     * Initial function : It will call the helper method to call the webservise method
     * *********************************************************************************/
	doInit : function(component, event, helper) {
		helper.callWebService(component, event, helper);
	}
})