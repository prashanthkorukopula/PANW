({
    generateDefaultScenario : function(component, product) {
        var defaultValues = component.get("v.scenarioWrapper");
        if (product == null) product = component.get("v.products")[0].value;
        var productDataSheet = defaultValues.productDataSheet[product];
        var productQuantity = defaultValues.existingProducts[product];
        var scenario = {
                        'Product_Family__c' : product,
                        'Refresh_Product_Family__c' : productDataSheet == null ? '' : productDataSheet.Refresh_Product_Family__c ,
                        'Existing_Hardware_Quantity__c' : productQuantity,
                        'Refresh_Hardware_Quantity__c' : productQuantity,
                        'Refresh_Hardware_Discount__c' : defaultValues.discounts['HW'],
                        'Existing_Subscription_Discount__c' : defaultValues.discounts['Product/Subscription Service'],
                        'Refresh_Subscription_Discount__c' : defaultValues.discounts['Product/Subscription Service'],
                        'Existing_Support_Discount__c' : defaultValues.discounts['Support'],
                        'Refresh_Support_Discount__c' : defaultValues.discounts['Support'],
                        'Existing_Support_Level__c' : 'Premium ',
                        'Refresh_Support_Level__c' : 'Premium ',
                        'Subscription_Per_Firewall__c' : 3,
                        'Include_In_Cumulative_Calculation__c' : true,
                        '_CapexOneYearRenewCost' : 'NA',
                        '_OpexOneYearRenewCost' : '',
                        '_CapexOneYearRefreshCost' : '',
                        '_OpexOneYearRefreshCost' : '',
                        '_TotalOneYearRefreshCost' : '',
                        '_CapexThreeYearRenewCost' : 'NA',
                        '_OpexThreeYearRenewCost' : '',
                        '_CapexThreeYearRefreshCost' : '',
                        '_OpexThreeYearRefreshCost' : '',
                        '_TotalThreeYearRefreshCost' : '',
                        '_SavingOneYear' : '',
                        '_SavingThreeYear' : '',
                        '_PercentSavingOneYear' : '',
                        '_PercentSavingThreeYear' : '',
                        '_chart':'',
                        'OpportunityId__c' : defaultValues.opportunity.Id
                       };
        return scenario;
    },
    saveScenariosToDatabase : function(component, event, saveCharts) {
        var lstScenarios = component.get("v.scenarios");
        if ( lstScenarios == null || lstScenarios==undefined || lstScenarios.length ==0 ) {
            return;
        }
        this.showSldsSpinner(component, "refreshSpinner");
        var lstScenariosClone = lstScenarios.slice(0, lstScenarios.length);
        for (var index in lstScenariosClone) {
            lstScenariosClone[index]._chart = '';
        }
        if (saveCharts == true) {
            var chartData = document.getElementsByClassName('comparisonGraph');
            if (chartData != null) {
                for (var index in lstScenariosClone)
                    if (lstScenariosClone.Include_In_Cumulative_Calculation__c != false)
                        lstScenariosClone[index].Chart_Data__c = chartData[index].toDataURL().replace('data:image/png;base64,','');
            }
        }
        var scenarios = JSON.stringify(lstScenariosClone);
        var action = component.get("c.saveScenarios");
        action.setParams({
            "jsonScenarios": scenarios
        });
        
        action.setCallback(this,function(result){
            //TODO Error handling
            console.log(result.getReturnValue());
            this.hideSldsSpinner(component, "refreshSpinner");
            if (result.getState() =='SUCCESS') {
                if ($A.getRoot().toString().includes("one:one")) {
                    var refreshView = $A.get('e.force:refreshView');
                    if (refreshView) {
                        $A.get('e.force:refreshView').fire();
                        var scenarios = result.getReturnValue();
                        component.set("v.scenarios", scenarios);
                        this.showToast('Scenarios successfully saved.', '');
                    }
                    
                    if(saveCharts == true) {
                        this.navigateToPdfPage(component);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    /*getScenariosFromDatabase : function (component, event) {
        var action = component.get("c.getScenarios");
        var opportunityId = '0063D000007Jkhz';
        action.setParams({
            opportunityId: opportunityId
        });
        
        action.setCallback(this,function(result){
            var scenarios = component.get("v.scenarios");
            var data = result.getReturnValue();
            if(data !== null && data !== '') {
               scenarios = data;
            } else {
                
            }
            
        });
        $A.enqueueAction(action);
    },*/
    removeScenario : function(component, event) {
        var scenarios = component.get("v.scenarios");
        var dataIndex = parseInt(event.getSource().get("v.name"));
        var scenarioToRemove;
        if (scenarios != null && scenarios.indexOf(dataIndex) != null) {
            scenarioToRemove = scenarios.splice(dataIndex, 1)[0];
            if (scenarioToRemove.Id == null || scenarioToRemove.Id == '') {
                component.set("v.scenarios", scenarios);
                this.updateCumulativeScenario(component);
                this.updateCumulativeChart(component);
                this.showToast('Scenario Removed.', '');
            } else {
                //removeScenarioFromDatabase(component, event);
                var action = component.get("c.deleteScenarios");
                action.setParams({
                    scenarioId: scenarioToRemove.Id
                });
                
                action.setCallback(this,function(result){
                    var state = result.getState();
                    if (state === 'SUCCESS'){
                        component.set("v.scenarios", scenarios);
                        this.showToast('Scenario Removed.', '');
                    }
                });
                $A.enqueueAction(action);
            }   
        }
    },
    generateDefaultScenarios : function(component) {
        var scenarios = [];
        var products = component.get("v.products");
        for (var index in products) {
            scenarios.push(this.generateDefaultScenario(component, products[index].value));
        }
        component.set("v.scenarios", scenarios);
    },
    generateComparisonData : function(component) {
        var scenarios = component.get("v.scenarios");
        var scenariosUpdated = [];
        
        for (var index in scenarios) {
            scenariosUpdated.push(this.generateComparisonDataForScenario(component, scenarios[index]));
        }
        component.set("v.scenarios", scenariosUpdated);
    },
    generateComparisonDataForScenario : function(component, scenario) { 
        var scenarioWrapper = component.get("v.scenarioWrapper");
        var product = scenarioWrapper.productDataSheet[scenario.Product_Family__c ];
        var refreshfProduct =scenarioWrapper.productDataSheet[scenario.Refresh_Product_Family__c];
        if (product == null || refreshfProduct == null) {
            return scenario;
        }
        scenario._OpexOneYearRenewCost = parseInt (Math.ceil (((product.Subscription_Cost_1_Year__c  * (1 - (scenario.Existing_Subscription_Discount__c  / 100)) * scenario.Subscription_Per_Firewall__c ) + (product.Premium_Support_Cost_1_Year__c  * (scenario.Existing_Support_Level__c == "Standard" ? 0.75 : (scenario.Existing_Support_Level__c  == "4Hr Premium" ? 1.3125 : 1)) * (1 - scenario.Existing_Support_Discount__c  / 100))) * scenario.Existing_Hardware_Quantity__c));
        scenario._OpexOneYearRefreshCost = parseInt (Math.ceil (( (refreshfProduct.Subscription_Cost_1_Year__c * scenario.Subscription_Per_Firewall__c * (1 - (scenario.Refresh_Subscription_Discount__c / 100))) + (refreshfProduct.Premium_Support_Cost_1_Year__c * (scenario.Refresh_Support_Level__c == "Standard" ? 0.75 : (scenario.Refresh_Support_Level__c == "4Hr Premium" ? 1.3125 : 1)) * (1 - (scenario.Refresh_Support_Discount__c / 100)))) * scenario.Refresh_Hardware_Quantity__c));
        scenario._CapexOneYearRefreshCost = parseInt(Math.ceil ((refreshfProduct.Hardware_Cost__c  * (1 - (scenario.Refresh_Hardware_Discount__c / 100))) * scenario.Refresh_Hardware_Quantity__c));
        scenario._TotalOneYearRefreshCost = scenario._OpexOneYearRefreshCost == NaN || scenario._CapexOneYearRefreshCost == NaN ? 0.0 : scenario._OpexOneYearRefreshCost + scenario._CapexOneYearRefreshCost;
        scenario._OpexThreeYearRenewCost = parseInt (Math.ceil (((product.Subscription_Cost_3_Year__c  * (1 - (scenario.Existing_Subscription_Discount__c  / 100)) * scenario.Subscription_Per_Firewall__c ) + (product.Premium_Support_Cost_3_Year__c  * (scenario.Existing_Support_Level__c == "Standard" ? 0.75 : (scenario.Existing_Support_Level__c  == "4Hr Premium" ? 1.3125 : 1)) * (1 - scenario.Existing_Support_Discount__c  / 100))) * scenario.Existing_Hardware_Quantity__c));
        scenario._OpexThreeYearRefreshCost = parseInt (Math.ceil (((refreshfProduct.Subscription_Cost_3_Year__c * scenario.Subscription_Per_Firewall__c * (1 - (scenario.Refresh_Subscription_Discount__c / 100))) + (refreshfProduct.Premium_Support_Cost_3_Year__c * (scenario.Refresh_Support_Level__c == "Standard" ? 0.75 : (scenario.Refresh_Support_Level__c == "4Hr Premium" ? 1.3125 : 1)) * (1 - (scenario.Refresh_Support_Discount__c / 100)))) * scenario.Refresh_Hardware_Quantity__c));
        scenario._CapexThreeYearRefreshCost = parseInt(Math.ceil ((refreshfProduct.Hardware_Cost__c  * (1 - (scenario.Refresh_Hardware_Discount__c / 100))) * scenario.Refresh_Hardware_Quantity__c));
        scenario._TotalThreeYearRefreshCost = scenario._OpexThreeYearRefreshCost == NaN || scenario._CapexThreeYearRefreshCost == NaN ? 0.0 : scenario._OpexThreeYearRefreshCost + scenario._CapexThreeYearRefreshCost;
        scenario._SavingOneYear = (scenario._OpexOneYearRefreshCost - scenario._OpexOneYearRenewCost);
        scenario._SavingThreeYear = (scenario._OpexThreeYearRefreshCost - scenario._OpexThreeYearRenewCost);
        if (scenario._SavingOneYear == null ){
            scenario._SavingOneYear = 0;
        }
        if (scenario._SavingThreeYear == null ){
            scenario._SavingThreeYear = 0;
        }
        scenario._PercentSavingOneYear = scenario._OpexOneYearRenewCost == 0 ? 'NA' : Math.round((scenario._SavingOneYear / (scenario._OpexOneYearRenewCost) * 100).toFixed(2));
        scenario._PercentSavingThreeYear = scenario._OpexThreeYearRenewCost == 0 ? 'NA' : Math.round((scenario._SavingThreeYear / (scenario._OpexThreeYearRenewCost) * 100).toFixed(2));
        return scenario;
    },
    openDialog : function(component, className) {
        $A.util.removeClass(component, className + 'hide');
        $A.util.addClass(component, className + 'open');
    },
    closeDialog : function(component, className) {
        $A.util.removeClass(component, className + 'open');
        $A.util.addClass(component, className + 'hide');
    },
    updateCumulativeScenario : function(component) {
        var cumulativeScenario = component.get("v.cumulativeScenario");
        var cumulativeChart = '';
        if (cumulativeScenario != '') {
            cumulativeChart = cumulativeScenario._chart;
        } 
        cumulativeScenario = {
            '_OpexOneYearRenewCost' : 0.0,
            '_OpexOneYearRefreshCost' : 0.0,
            '_CapexOneYearRefreshCost' : 0.0,
            '_TotalOneYearRefreshCost' : 0.0,
            '_OpexThreeYearRenewCost' : 0.0,
            '_OpexThreeYearRefreshCost' : 0.0,
            '_CapexThreeYearRefreshCost' : 0.0,
            '_TotalThreeYearRefreshCost' : 0.0,
            '_SavingOneYear' : 0.0,
            '_SavingThreeYear' : 0.0,
            '_chart' : cumulativeChart
        };
        var scenarios = component.get("v.scenarios");
        for (var index in scenarios) {
            if (scenarios[index].Include_In_Cumulative_Calculation__c == false) continue;
            if (scenarios[index]._OpexOneYearRenewCost != null) 
                cumulativeScenario._OpexOneYearRenewCost += scenarios[index]._OpexOneYearRenewCost;
            if (scenarios[index]._OpexOneYearRefreshCost != null)
                cumulativeScenario._OpexOneYearRefreshCost += scenarios[index]._OpexOneYearRefreshCost;
            if (scenarios[index]._CapexOneYearRefreshCost != null)
                cumulativeScenario._CapexOneYearRefreshCost += scenarios[index]._CapexOneYearRefreshCost;
            if (scenarios[index]._TotalOneYearRefreshCost != null)
                cumulativeScenario._TotalOneYearRefreshCost += scenarios[index]._TotalOneYearRefreshCost;
            if (scenarios[index]._OpexThreeYearRenewCost != null)
                cumulativeScenario._OpexThreeYearRenewCost += scenarios[index]._OpexThreeYearRenewCost;
            if (scenarios[index]._OpexThreeYearRefreshCost != null)
                cumulativeScenario._OpexThreeYearRefreshCost += scenarios[index]._OpexThreeYearRefreshCost;
            if (scenarios[index]._CapexThreeYearRefreshCost != null)
                cumulativeScenario._CapexThreeYearRefreshCost += scenarios[index]._CapexThreeYearRefreshCost;
            if (scenarios[index]._TotalThreeYearRefreshCost != null)
                cumulativeScenario._TotalThreeYearRefreshCost += scenarios[index]._TotalThreeYearRefreshCost;
            if (scenarios[index]._SavingOneYear != null)
                cumulativeScenario._SavingOneYear += scenarios[index]._SavingOneYear;
            if (scenarios[index]._SavingThreeYear != null)
                cumulativeScenario._SavingThreeYear += scenarios[index]._SavingThreeYear;
        }
        cumulativeScenario._PercentSavingOneYear = cumulativeScenario._OpexOneYearRenewCost == 0 ? 100 : Math.round((cumulativeScenario._SavingOneYear / (cumulativeScenario._OpexOneYearRenewCost) * 100).toFixed(2));
        cumulativeScenario._PercentSavingThreeYear = cumulativeScenario._OpexThreeYearRenewCost == 0 ? 100 :  Math.round((cumulativeScenario._SavingThreeYear / (cumulativeScenario._OpexThreeYearRenewCost) * 100).toFixed(2));;
        if (isNaN(cumulativeScenario._PercentSavingOneYear)) cumulativeScenario._PercentSavingOneYear = 0.0;
        if (isNaN(cumulativeScenario._PercentSavingThreeYear)) cumulativeScenario._PercentSavingThreeYear = 0.0;

        component.set("v.cumulativeScenario", cumulativeScenario);
    },
    updateOnScenarioChange : function (component, event, index) {
        var defaultValues = component.get('v.scenarioWrapper');
        var scenarios =  component.get('v.scenarios');
        scenarios[index] = this.generateComparisonDataForScenario(component, scenarios[index]);
        component.set('v.scenarios', scenarios);
        //Refresh Bar chart only if model changed
        if (event.getSource().get('v.class').indexOf('refresh_bar_chart') !== -1) {
            this.updateBarChart(component, index);
        }
        this.updateCumulativeScenario(component);
        this.updateCumulativeChart(component);
    },
    getRelatedOpportunities : function (component, event) {
        //TODO spinner
        var refresh = component.find('refreshOpportunity');
        var recordId = component.get("v.recordId");
        //this.showSldsSpinner(refresh, "refreshSpinner");
        var action = component.get("c.getRelatedOpportunities");
        action.setBackground();
        //var opportunityId = '0063D000007Jkhz';
        action.setParams({
            opportunityId: recordId
        });

        //TODO: Error handling and Exception Handling        
        action.setCallback(this,function(result){
            if (result.getState() == 'SUCCESS') {
                component.set("v.relatedOpportunities", result.getReturnValue());
                //this.hideSldsSpinner(refresh, "refreshSpinner");
            }
        });
        $A.enqueueAction(action);
    },
    //ChartJS methods
    createCumulativeChart : function(component) {
        var cumulativeScenario = component.get("v.cumulativeScenario");
        var div = component.find("canvasCumulative").getElement();
        if (div == null) return;
        var canvas = div.firstChild;
        var ctx = canvas.getContext("2d");
        var cumulativeChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["1 Year Cost", "3 Year Cost"],
                datasets: [{
                    label: 'Renew Opex $',
                    backgroundColor: "rgba(201, 22, 18, 0.8)",
                    borderColor: "rgba(201, 22, 18, 1)",
                    borderWidth: 2,
                    data: [cumulativeScenario._OpexOneYearRenewCost == 0 ? null : cumulativeScenario._OpexOneYearRenewCost, 
                        cumulativeScenario._OpexThreeYearRenewCost == 0 ? null : cumulativeScenario._OpexThreeYearRenewCost],
                    stack:1
                }, {
                    label: 'Refresh Opex $',
                    backgroundColor: "rgba(0, 140, 140, 0.6)",
                    borderColor: "rgba(0, 42, 42, 1)",
                    borderWidth: 2,
                    data: [cumulativeScenario._OpexOneYearRefreshCost, cumulativeScenario._OpexThreeYearRefreshCost],
                    stack:2
                },{
                    label: 'Refresh Capex $',
                    backgroundColor: "rgba(0, 42, 42, 0.8)",
                    borderColor: "rgba(0, 42, 42, 1)",
                    borderWidth: 2,
                    data: [cumulativeScenario._CapexOneYearRefreshCost, cumulativeScenario._CapexThreeYearRefreshCost],
                    stack:2
                }]
            },
            options: {
                title: {
                    display: true,
                    text: 'Cumulative Cost Comparison'
                },
               scales: {
                        yAxes: [{
                                type: 'logarithmic',
                                stacked:true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Cost in $'
                                },
                                ticks: {
                                    beginAtZero:true,
                                    userCallback: function(value, index, values) {
                                        var first = value;
                                        while(first >= 10) {
                                            first = first/10;
                                        }
                                        if(first==1)
                                            return value.toLocaleString();
                                    }
                                }
                            }],
                        xAxes: [{
                            ticks: {
                            },
                            scaleLabel: {
                                display:true
                            }
                        }]
                    },
                legend: {
                    display:true,
                    position:'right'
                },
                tooltips: {
                    mode:'label'
                }
            }
        });
        cumulativeScenario._chart = cumulativeChart;
    },
    updateCumulativeChart : function(component) {
        var cumulativeScenario = component.get("v.cumulativeScenario");
        var cumulativeChart = cumulativeScenario._chart;

        cumulativeChart.data.labels.pop();
        cumulativeChart.data.datasets.forEach((dataset) => {
            dataset.data.pop();
        });
        cumulativeChart.data = {
                labels: ["1 Year Cost", "3 Year Cost"],
                datasets: [{
                    label: 'Renew Opex $',
                    backgroundColor: "rgba(201, 22, 18, 0.8)",
                    borderColor: "rgba(201, 22, 18, 1)",
                    borderWidth: 2,
                    data: [cumulativeScenario._OpexOneYearRenewCost == 0 ? null : cumulativeScenario._OpexOneYearRenewCost, 
                        cumulativeScenario._OpexThreeYearRenewCost == 0 ? null : cumulativeScenario._OpexThreeYearRenewCost],
                    stack:1
                }, {
                    label: 'Refresh Opex $',
                    backgroundColor: "rgba(0, 140, 140, 0.6)",
                    borderColor: "rgba(0, 42, 42, 1)",
                    borderWidth: 2,
                    data: [cumulativeScenario._OpexOneYearRefreshCost, cumulativeScenario._OpexThreeYearRefreshCost],
                    stack:2
                },{
                    label: 'Refresh Capex $',
                    backgroundColor: "rgba(0, 42, 42, 0.8)",
                    borderColor: "rgba(0, 42, 42, 1)",
                    borderWidth: 2,
                    data: [cumulativeScenario._CapexOneYearRefreshCost, cumulativeScenario._CapexThreeYearRefreshCost],
                    stack:2
                }]
            };
        cumulativeChart.update();
    },
    createBarChart : function(component, index, product1, product2, productDataSheet) {
        if (index == undefined || index == null) return;
        var scenarios = component.get("v.scenarios");
        var div = scenarios.length == 1 ? component.find("canvasProdComparison").getElement() : 
                component.find("canvasProdComparison")[index].getElement();
        if (div == null) return;
        var scenarioWrapper = component.get("v.scenarioWrapper");
        
        var canvas = div.firstChild;
        var ctx = canvas.getContext("2d");
        if (product1 == undefined || product2 == undefined || product1 == null || product2 == null) return;
        var productComparisonData = this.getProductComparisonSpec(product1, product2, scenarioWrapper.productDataSheet);

        var barChart = new Chart(ctx, {
            type: "bar",
            data: productComparisonData,
            options: {
                title: {
                    display: true,
                    text: 'Performance Comparison' },
                legend: {
                    display:true,
                    position:'right'
                },
                scales: {
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: 'Mbps'
                        }
                    }]/*,
                    xAxes: [{
                        gridLines : {
                            display : false
                        }
                    }]*/
                },
                tooltips: {
                    mode:'label'
                }
            }
        });
        scenarios[index]._chart = barChart;
    },
    updateBarChart: function(component, index) {
        var scenarios = component.get("v.scenarioWrapper");
        var scenario = component.get("v.scenarios")[index];
        if (scenario == undefined || scenario == null) return;
        var chart = scenario._chart;
        chart.data.labels.pop();
        chart.data.datasets.forEach((dataset) => {
            dataset.data.pop();
        });
        chart.data = this.getProductComparisonSpec(scenario.Product_Family__c, scenario.Refresh_Product_Family__c, scenarios.productDataSheet);
        chart.update();
    },
    getProductComparisonSpec : function(product1, product2, productDataSheet) {
        var prod1DataSheet = [productDataSheet[product1].App_ID__c, 
            productDataSheet[product1].Threat__c,
            productDataSheet[product1].SSL_Inspection__c,
            productDataSheet[product1].IPSec_VPN__c];
        var prod2DataSheet = [productDataSheet[product2].App_ID__c, 
            productDataSheet[product2].Threat__c,
            productDataSheet[product2].SSL_Inspection__c,
            productDataSheet[product2].IPSec_VPN__c];
        var data = {
            labels: ["App-ID", "Threat", "SSL Inspect", "IPSec VPN"],
            datasets: [{
                label: product1,
                //backgroundColor: "rgba(255, 99, 132, 0.8)",
                backgroundColor: "rgba(168, 196, 56, 0.6)",
                //borderColor: "rgba(255,99,132,1)",
                borderColor: "rgba(168 , 196, 56, 1)",
                borderWidth: 2,
                data: prod1DataSheet}, {
                label: product2, 
                //backgroundColor: "rgba(54, 162, 235, 0.6)",
                backgroundColor : "rgba(10,149,196,0.6)",
                //borderColor: "rgba(54, 162, 235, 1)",
                borderColor: "rgba(10,149,196,1)",
                borderWidth: 2,
                data: prod2DataSheet
                }]
            };
        return data;
    },
    showSldsSpinner : function(component, auraId){
        var spinner = component.find(auraId);
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
    },
    hideSldsSpinner : function(component, auraId){
        var spinner = component.find(auraId);
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
    },
    createNewOpportunity : function(component, event) {
        this.showSldsSpinner(component, "refreshSpinner");
        var renewalOppty = component.get("v.scenarioWrapper").opportunity;
        var regEx = new RegExp('Renewal', "ig");
        var replaceMask = 'Refresh';
        var oppName = renewalOppty.Name.replace(regEx, replaceMask);
        if (oppName.includes('Refresh') == false) oppName = 'Refresh/' + oppName;
        if (oppName != null && oppName.length >= 120) {
            oppName = oppName.subString(0, 119);
        }
        // Create Opportunity object
        var opp = {
                "recordTypeId" : "01270000000Hgep", 
                'AccountId' : renewalOppty.AccountId,
                'Name' : oppName, 
                'CampaignId' : renewalOppty.CampaignId,
                'Primary_Purchase_Driver__c' : renewalOppty.Primary_Purchase_Driver__c,
                'Secondary_Purchase_Driver__c' : renewalOppty.Secondary_Purchase_Driver__c,
                'Distributor__c' : renewalOppty.Distributor__c,
                'Type' : 'Expand Business',
                'StageName' : '1 - Open Qualified',
                'FlagAsRefreshOpportunityOnCreate__c' : true,
                'Related_Opportunity__c' : renewalOppty.Id,
                'City_of_Deployment__c' : renewalOppty.City_of_Deployment__c,
                'Customer_Evaluation__c' : renewalOppty.Customer_Evaluation__c,
                'Customer_Problem_Discription__c' : renewalOppty.Customer_Problem_Discription__c,
                'Distributor_Contact__c' : renewalOppty.Distributor_Contact__c,
                'Reseller_SE_Contact__c' : renewalOppty.Reseller_SE_Contact__c,
                'Date_Eval_Started_INTL_Deal__c' : renewalOppty.Date_Eval_Started_INTL_Deal__c,
                'Evaluation_Status__c' : renewalOppty.Evaluation_Status__c,
                'Main_Competitor__c' : renewalOppty.Main_Competitor__c,
                'Next_Step_in_Sales_Cycle__c' : renewalOppty.Next_Step_in_Sales_Cycle__c,
                'CloseDate' : renewalOppty.CloseDate,
                'Platform_of_nterest__c' : renewalOppty.Platform_of_nterest__c,
                'Second_Tier_Reseller__c' : renewalOppty.Second_Tier_Reseller__c,
                'Sub_Type__c' : 'Refresh'
            };

        // Create Scenarios
        var lstScenarios = component.get("v.scenarios");
        if ( lstScenarios == null || lstScenarios==undefined || lstScenarios.length ==0 ) {
            return;
        }
        this.showSldsSpinner(component, "refreshSpinner");
        var lstScenariosClone = lstScenarios.slice(0, lstScenarios.length);
        for (var index in lstScenariosClone) {
            lstScenariosClone[index]._chart = '';
        }
        var scenarios = JSON.stringify(lstScenariosClone);
        var oppJSON = JSON.stringify(opp);
        var action = component.get("c.createOpportunity");
        action.setParams({
            "jsonScenarios": scenarios,
            "jsonOpp" : oppJSON
        });

        action.setCallback(this,function(result){
            console.log(result.getReturnValue());
            this.hideSldsSpinner(component, "refreshSpinner");
            if (result.getState() =='SUCCESS') {
                var newOpp = result.getReturnValue();
                if ($A.getRoot().toString().includes('one:one')) {
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({ 
                    "recordId": newOpp.Id});
                    navEvt.fire();
                } else
                    window.location.href = '/' + newOpp.Id; 
            }
        });
        $A.enqueueAction(action);;
    },
    showToast : function(title, message) {
        if ($A.getRoot().toString().includes('one:one')) {
            var toast = $A.get("e.force:showToast");
            if (toast) {
                toast.setParams({
                    "title": title,
                    "message" : message
                });
                toast.fire()
            }
        }
    },
    toggleHelper : function(component,event) {
        var toggleText = event.currentTarget.id;
        var toggleElement = document.getElementById('infoDisplay_' + toggleText.replace('tooltip_', ''));
        if (toggleElement != null)
            $A.util.toggleClass(toggleElement, "toggle");
    },
    generatePdf : function(component, event) {
        this.saveScenariosToDatabase(component, event, true);
    },
    navigateToPdfPage : function (component) {
        var recordId = component.get("v.recordId");
        window.open("/apex/RefreshOptimizerPdf?Id="+recordId, '_blank');
    }
})