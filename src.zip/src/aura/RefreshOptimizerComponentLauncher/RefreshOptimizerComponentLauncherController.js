({   
	doInit : function(component, event, helper) {
        var action = component.get("c.initializeComponent");
        action.setParams({
            opportunityId: component.get("v.recordId")
        });
        //TODO: Error handling and Exception Handling        
        action.setCallback(this, function(result){
            console.log(result);
            if (result.getState() == 'SUCCESS') {
               	var evt = $A.get("e.force:navigateToComponent");
               	evt.setParams({
                    componentDef: "c:RefreshOptimizerComponent",
                    componentAttributes: {
                         recordId: component.get('v.recordId')
                    }
                }); 
            	evt.fire();
            }else{
                var errors = action.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        component.set('v.errorMessage', errors[0].message);
                    }
                }

            }
        });
        $A.enqueueAction(action);
	}   
})