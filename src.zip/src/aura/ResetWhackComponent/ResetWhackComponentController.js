({
	doInit : function(component, event, helper) {
        try{
        //Current Record Id 
        var recId = component.get("v.recordId");
		if (confirm("This operation will remove all active licenses on the device. Are you sure to remove?")) {
        	var urlEvent = $A.get("e.force:navigateToURL");
            // set the url to be directed to
            urlEvent.setParams({
                "url": "/apex/eval_inventory_reset?id="+recId
            });   
            urlEvent.fire(); 
        }else{
        	var dismissActionPanel = $A.get("e.force:closeQuickAction");
            dismissActionPanel.fire();  
        }
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
	}
})