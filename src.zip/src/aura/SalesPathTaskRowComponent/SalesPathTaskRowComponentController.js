({
	fireTaskEvent : function(component, event, helper) {
 
     	 var getSelectTask= component.get("v.objout");

      	var compEvent = component.getEvent("oSelectedTaskEvent");

         compEvent.setParams({"selectedTask" : getSelectTask });  

         compEvent.fire();
	},

	gotoURL : function (component, event, helper) {
		 var getSelectTask= component.get("v.objout");

    // var urlEvent = $A.get("e.force:navigateToURL");
    // urlEvent.setParams({
    //   "url": getSelectTask.link
    // });
    // urlEvent.fire();

    var compEvent = component.getEvent("oSelectedTaskEvent");

         compEvent.setParams({"selectedTask" : getSelectTask });  

         compEvent.fire();
        if(getSelectTask.tcoBattleCard=='Battle Card'){
            if(getSelectTask.link != null){
                console.log('link ---->',getSelectTask.link)
                window.open('/'+getSelectTask.link, '_blank');
            }
              
        }
        
  
      	
}
})