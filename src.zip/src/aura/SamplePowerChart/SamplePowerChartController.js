({
	scriptsLoaded: function(component, event, helper) {
        var orgch = component.find("people").getElement();
        console.log('check elemnet----->',orgch);
        var orgchart = new getOrgChart(orgch, {
            theme: "vivian",
            dataSource: [
                { id: 1, parentId: null, Name: "Amber McKenzie"},
                { id: 2, parentId: 1, Name: "Ava Field"},
                { id: 3, parentId: 1, Name: "Evie Johnson"}]
        });
    }
})