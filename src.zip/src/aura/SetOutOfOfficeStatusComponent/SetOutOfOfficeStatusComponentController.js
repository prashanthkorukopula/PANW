({
    doInit: function(component, event, helper) {
        var action = component.get("c.getCurrentUser"); // method in the apex class
        action.setCallback(this, function(a) {
            component.set("v.runningUser", a.getReturnValue()); // variable in the component
            console.log('user data',a.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    sectionOne : function(component, event, helper) {
       helper.helperFun(component,event,'articleOne');
    },
    
   sectionTwo : function(component, event, helper) {
      helper.helperFun(component,event,'articleTwo');
    },
    editsection : function(component, event,helper) {
      helper.helpereditsection(component,event);
    },
    
    showeditPanel : function (component, event,helper){
     	helper.helpereditpanel(component,event);
    },
    saveCon : function(component, event) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
        var con = component.get("v.runningUser");
        
        var action1 = component.get("c.saveUser");
        action1.setParams({
            "userObj": con
        });
        action1.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state--'+state);            
            if (component.isValid() && state === "SUCCESS") {
                console.log('con ----->'+response.getReturnValue());
                component.set("v.runningUser", response.getReturnValue());
                var acc = component.find('initialItem');
                var displaypanel = component.find('editpanel');
                var edtbtn = component.find('editbtn');
                var savebtn = component.find('savebtn');
                $A.util.removeClass(displaypanel, 'slds-show');
        		$A.util.addClass(displaypanel, 'slds-hide');
                $A.util.removeClass(acc, 'slds-hide');
        		$A.util.addClass(acc, 'slds-show');
                $A.util.removeClass(edtbtn, 'slds-hide');
                $A.util.addClass(edtbtn, 'slds-show');
                $A.util.removeClass(savebtn, 'slds-show');
                $A.util.addClass(savebtn, 'slds-hide');		
            }
        });
        $A.enqueueAction(action1);
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
    },
    refresh : function(component, event, helper) {
    var action = component.get('c.getCurrentUser');
    action.setCallback(component,
        function(response) {
            var state = response.getState();
            if (state === 'SUCCESS'){
                $A.get('e.force:refreshView').fire();
            } else {
                 //do something
            }
        }
    );
    $A.enqueueAction(action);
}
   
   
})