({
    orgChart: {},
    clickEvent :{},
    eventname: '',
    
    contactLevelWidth : ['25%','50%','75%'],
    contactLevelColors : ['#FFF200','#FFA500', '#109618'],
    contactLevels : ["Low","Medium", "High"],
    
    chartZoom : 1,
    
    
    overrideHeaderStyle : function(component, event, helper){
   	 component.set("v.cssStyle", ".forceStyle .viewport.oneHeader.desktop {z-index:0} .forceStyle.desktop .viewport{overflow:hidden}");
	}

 })