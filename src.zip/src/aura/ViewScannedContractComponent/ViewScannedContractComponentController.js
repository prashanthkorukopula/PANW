({
	doInit : function(component, event, helper) {
        try{
        var recId = component.get("v.recordId");
        var action = component.get("c.getCustomCtrctRecord");
        action.setParams({
            "recordId": component.get("v.recordId")
        });
                
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var agmt = data.AGMT_PDF_Filename__c;
            var urlEvent = $A.get("e.force:navigateToURL");
            if(agmt != null && agmt !='' && agmt!='undefined'){
                urlEvent.setParams({
                    "url": "\\\\filer1\\shares\\Departments\\Sales\\Channels\\Agreements\\"+agmt+".pdf"
                });   
                urlEvent.fire();  
                var dismissActionPanel = $A.get("e.force:closeQuickAction");
            	dismissActionPanel.fire();
            }else{
                alert("The Agreement File Name is empty");
                var dismissActionPanel = $A.get("e.force:closeQuickAction");
                dismissActionPanel.fire();
            }
        });
        $A.enqueueAction(action);
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
	}
})